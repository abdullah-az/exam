
import { Specialization, UserRole, ExamType } from './types';

export const APP_NAME = "منصة امتحان الهندسة المعلوماتية الموحد";

export const SPECIALIZATIONS: Specialization[] = [
  Specialization.SOFTWARE_ENGINEERING,
  Specialization.NETWORK_ENGINEERING,
  Specialization.ARTIFICIAL_INTELLIGENCE,
  Specialization.GENERAL,
];

export const USER_ROLES: UserRole[] = [
  UserRole.ADMIN,
  UserRole.STUDENT,
];

export const ATTACHMENT_TYPES: Array<'image' | 'code' | 'diagram' | 'text'> = ['image', 'code', 'diagram', 'text'];

export const MOCK_EXAM_QUESTIONS_COUNT = [5, 10, 15, 20];

export const INITIAL_QUESTION_FORM_DATA_AR = {
  text: "",
  specialization: Specialization.GENERAL,
  // year removed
  // marks removed
  option1Text: "",
  option2Text: "",
  option3Text: "",
  option4Text: "",
  correctOptionIndex: "0",
  attachmentName: "",
  attachmentType: "" as const,
  attachmentUrlOrContent: "",
};

export const EXAM_TYPES: Array<{ value: ExamType; label: string }> = [
  { value: ExamType.REGULAR, label: 'امتحان اعتيادي (من بنك الأسئلة)' },
  { value: ExamType.SMART, label: 'امتحان ذكي (مولّد بالذكاء الاصطناعي)' },
];

export const MIN_SAMPLE_QUESTIONS_FOR_SMART_EXAM = 1; // Minimum questions needed in a specialization to enable smart exam mode based on them.
export const MAX_SAMPLE_QUESTIONS_TO_SEND_TO_AI = 3; // Max samples to send to AI to avoid overly long prompts.