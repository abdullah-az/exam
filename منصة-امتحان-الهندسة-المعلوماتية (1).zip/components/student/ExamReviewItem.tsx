
import React from 'react';
import { Question, ExamAnswer, Attachment } from '../../types';

interface ExamReviewItemProps {
  question: Question;
  studentAnswer?: ExamAnswer;
  questionIndex: number;
}

const AttachmentDisplay: React.FC<{ attachment: Attachment }> = ({ attachment }) => {
    return (
        <div className="mt-4 p-4 border border-slate-200 rounded-lg bg-slate-50 text-sm">
            <p className="font-semibold text-slate-700">مرفق: {attachment.name} <span className="text-xs text-slate-500">({attachment.type})</span></p>
            {attachment.type === 'image' && attachment.urlOrContent && (
                 <img src={attachment.urlOrContent} alt={attachment.name} className="max-w-full h-auto max-h-60 rounded-md mt-2 shadow-sm border border-slate-300"/>
            )}
            {(attachment.type === 'code' || attachment.type === 'text' || attachment.type === 'diagram') && attachment.urlOrContent && (
                 attachment.urlOrContent.startsWith('http') ? 
                 <a href={attachment.urlOrContent} target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:text-indigo-800 hover:underline block mt-2 break-all" title={attachment.urlOrContent}>عرض المرفق (رابط خارجي)</a>
                 : <pre className="mt-2 p-3 bg-white rounded-md text-xs whitespace-pre-wrap border border-slate-200 max-h-40 overflow-auto"><code>{attachment.urlOrContent}</code></pre>
            )}
        </div>
    );
};

const ExamReviewItem: React.FC<ExamReviewItemProps> = ({ question, studentAnswer, questionIndex }) => {
  const isCorrect = studentAnswer?.selectedOptionId === question.correctOptionId;
  const studentSelectedOption = question.options.find(opt => opt.id === studentAnswer?.selectedOptionId);

  return (
    <div className={`p-6 rounded-xl shadow-lg mb-8 border-l-4 ${isCorrect ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50'}`}>
      <div className="flex justify-between items-baseline mb-2">
        <p className="text-sm text-slate-600">
            السؤال {questionIndex + 1}
        </p>
        {isCorrect ? 
            <span className="text-sm font-semibold text-green-700 bg-green-200 px-2.5 py-1 rounded-full">إجابة صحيحة (+1 نقطة)</span> 
            : 
            <span className="text-sm font-semibold text-red-700 bg-red-200 px-2.5 py-1 rounded-full">إجابة خاطئة</span>
        }
      </div>
      <h4 className="text-lg font-semibold text-slate-800 mb-4 leading-relaxed">{question.text}</h4>

       {question.attachments && question.attachments.length > 0 && (
        <div className="mb-4">
          {question.attachments.map(att => <AttachmentDisplay key={att.id} attachment={att} />)}
        </div>
      )}

      <div className="space-y-3">
        {question.options.map((option, idx) => {
          let optionStyle = "p-3.5 border rounded-lg text-slate-800 flex items-center text-sm sm:text-base ";
          let indicatorIcon = null;

          if (option.id === question.correctOptionId) {
            optionStyle += "bg-green-100 border-green-400 font-medium ring-2 ring-green-300"; 
            indicatorIcon = (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-600 mr-2 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
            );
          } else if (option.id === studentAnswer?.selectedOptionId) {
            optionStyle += "bg-red-100 border-red-400 ring-2 ring-red-300"; // Student's incorrect choice
             indicatorIcon = (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-600 mr-2 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
            );
          } else {
            optionStyle += "bg-slate-100 border-slate-300 text-slate-700"; // Other options
          }

          return (
            <div key={option.id} className={optionStyle}>
              {indicatorIcon}
              <span className="font-mono mr-1 text-xs">{idx + 1}.</span>
              <span>{option.text}</span>
              {option.id === question.correctOptionId && <span className="ml-auto text-xs font-bold text-green-700 hidden sm:inline">(الإجابة الصحيحة)</span>}
              {option.id === studentAnswer?.selectedOptionId && option.id !== question.correctOptionId && <span className="ml-auto text-xs font-bold text-red-700 hidden sm:inline">(إجابتك)</span>}
            </div>
          );
        })}
      </div>
      {!studentSelectedOption && (
          <p className="mt-4 text-sm text-amber-700 bg-amber-100 p-3 rounded-lg border border-amber-300 font-medium">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 inline mr-1 -mt-0.5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.332-.21 3.031-1.742 3.031H4.42c-1.532 0-2.492-1.699-1.742-3.031l5.58-9.92zM10 13a1 1 0 100-2 1 1 0 000 2zm-1.75-5.5a1.75 1.75 0 103.5 0 1.75 1.75 0 00-3.5 0z" clipRule="evenodd" />
            </svg>
            لم تتم الإجابة على هذا السؤال.
          </p>
      )}
    </div>
  );
};

export default ExamReviewItem;
