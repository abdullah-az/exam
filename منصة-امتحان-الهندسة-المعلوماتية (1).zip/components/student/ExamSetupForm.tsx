import React, { useState, useEffect } from 'react';
import { Specialization, ExamType } from '../../types';
import { SPECIALIZATIONS, MOCK_EXAM_QUESTIONS_COUNT, EXAM_TYPES, MIN_SAMPLE_QUESTIONS_FOR_SMART_EXAM } from '../../constants';
import Button from '../shared/Button';
import Select from '../shared/Select';

interface ExamSetupFormProps {
  onSubmit: (specialization: Specialization, numQuestions: number, examType: ExamType) => void;
  availableQuestionsCount: (specialization: Specialization) => number;
  initialSpecialization?: Specialization; // Added to accept initial specialization
}

const ExamSetupForm: React.FC<ExamSetupFormProps> = ({ onSubmit, availableQuestionsCount, initialSpecialization }) => {
  const [selectedSpecialization, setSelectedSpecialization] = useState<Specialization>(initialSpecialization || SPECIALIZATIONS[0]);
  const [numQuestions, setNumQuestions] = useState<number>(MOCK_EXAM_QUESTIONS_COUNT[0]);
  const [selectedExamType, setSelectedExamType] = useState<ExamType>(ExamType.REGULAR);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Update selected specialization if initialSpecialization prop changes and is valid
    if (initialSpecialization && SPECIALIZATIONS.includes(initialSpecialization)) {
      setSelectedSpecialization(initialSpecialization);
    }
  }, [initialSpecialization]);


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const maxRegularQuestions = availableQuestionsCount(selectedSpecialization);

    if (numQuestions <= 0) {
        setError(`الرجاء اختيار عدد أسئلة صحيح.`);
        return;
    }

    if (selectedExamType === ExamType.REGULAR) {
      if (maxRegularQuestions === 0) {
          setError(`لا توجد أسئلة متاحة لهذا التخصص حالياً في بنك الأسئلة. الرجاء اختيار تخصص آخر أو جرب الامتحان الذكي.`);
          return;
      }
      if (numQuestions > maxRegularQuestions) {
          setError(`لا يوجد سوى ${maxRegularQuestions} سؤال متاح في بنك الأسئلة لهذا التخصص. الرجاء اختيار عدد أقل أو يساوي ${maxRegularQuestions}.`);
          return;
      }
    } else if (selectedExamType === ExamType.SMART) {
      if (maxRegularQuestions < MIN_SAMPLE_QUESTIONS_FOR_SMART_EXAM) {
        setError(`لإنشاء امتحان ذكي في تخصص "${selectedSpecialization}", يجب أن يحتوي بنك الأسئلة على ${MIN_SAMPLE_QUESTIONS_FOR_SMART_EXAM} سؤال واحد على الأقل في هذا التخصص كمرجع للذكاء الاصطناعي. يتوفر حاليًا ${maxRegularQuestions} أسئلة.`);
        return;
      }
      // For smart exams, numQuestions is the target number to generate.
      // No strict upper limit based on availableQuestionsCount here, as we are generating new ones.
    }
    onSubmit(selectedSpecialization, numQuestions, selectedExamType);
  };

  const specializationOptions = SPECIALIZATIONS.map(spec => ({ value: spec, label: spec }));
  const numQuestionsOptions = MOCK_EXAM_QUESTIONS_COUNT.map(num => ({ value: num, label: `${num} سؤال` }));
  
  const currentMaxRegularQuestions = availableQuestionsCount(selectedSpecialization);

  return (
    <div className="bg-white p-8 rounded-xl shadow-2xl max-w-lg mx-auto border-t-4 border-indigo-600">
      <h2 className="text-3xl font-bold text-indigo-700 mb-8 text-center">إعدادات الامتحان</h2>
      {error && <p className="text-red-700 bg-red-100 p-3.5 rounded-lg mb-6 text-sm font-medium">{error}</p>}
      <form onSubmit={handleSubmit} className="space-y-7">
        
        <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">اختر نوع الامتحان:</label>
            <div className="flex space-x-3 space-x-reverse rounded-lg bg-slate-100 p-1">
                {EXAM_TYPES.map((type) => (
                <button
                    key={type.value}
                    type="button"
                    onClick={() => {
                        setSelectedExamType(type.value);
                        setError(null);
                    }}
                    className={`w-full py-2.5 px-4 text-sm font-medium rounded-md transition-all duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-opacity-50
                    ${selectedExamType === type.value ? 'bg-indigo-600 text-white shadow-md' : 'bg-transparent text-slate-700 hover:bg-slate-200'}`}
                    aria-pressed={selectedExamType === type.value}
                >
                    {type.label}
                </button>
                ))}
            </div>
        </div>

        <Select
          label="اختر التخصص:"
          options={specializationOptions}
          value={selectedSpecialization}
          onChange={(e) => {
            setSelectedSpecialization(e.target.value as Specialization);
            setError(null);
          }}
          required
          aria-required="true"
        />
        <Select
          label="اختر عدد الأسئلة:"
          options={numQuestionsOptions}
          value={numQuestions}
          onChange={(e) => {
            setNumQuestions(parseInt(e.target.value));
            setError(null);
          }}
          required
          aria-required="true"
        />
        <div className="bg-indigo-50 p-3 rounded-lg text-sm text-indigo-700 space-y-1">
            {selectedExamType === ExamType.REGULAR && (
                <>
                    <p>
                        الأسئلة المتاحة في بنك الأسئلة للتخصص ({selectedSpecialization}): <span className="font-bold">{currentMaxRegularQuestions}</span>
                    </p>
                    {currentMaxRegularQuestions > 0 && numQuestions > currentMaxRegularQuestions && (
                        <p className="text-orange-600">ملاحظة: سيتم اختيار {currentMaxRegularQuestions} أسئلة فقط بناءً على المتوفر.</p>
                    )}
                </>
            )}
            {selectedExamType === ExamType.SMART && (
                 <p>
                    سيقوم الذكاء الاصطناعي بتوليد <span className="font-bold">{numQuestions}</span> أسئلة جديدة لتخصص "{selectedSpecialization}".
                 </p>
            )}
             {selectedExamType === ExamType.SMART && currentMaxRegularQuestions < MIN_SAMPLE_QUESTIONS_FOR_SMART_EXAM && (
                 <p className="text-amber-700">
                    تحذير: يتوفر فقط <span className="font-bold">{currentMaxRegularQuestions}</span> أسئلة في بنك الأسئلة كمرجع. قد تكون جودة الأسئلة المولدة أفضل إذا توفرت عينات أكثر.
                 </p>
            )}
        </div>
        <Button type="submit" variant="primary" size="lg" className="w-full">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 inline ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          بدء الامتحان
        </Button>
      </form>
    </div>
  );
};

export default ExamSetupForm;
