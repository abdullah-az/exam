
import React from 'react';
import { Question, Attachment } from '../../types';

interface ExamQuestionViewProps {
  question: Question;
  questionIndex: number;
  totalQuestions: number;
  selectedOptionId?: string;
  onOptionSelect: (questionId: string, optionId: string) => void;
}

const AttachmentDisplay: React.FC<{ attachment: Attachment }> = ({ attachment }) => {
    return (
        <div className="mt-4 p-4 border border-slate-200 rounded-lg bg-slate-50 text-sm">
            <p className="font-semibold text-slate-700">مرفق: {attachment.name} <span className="text-xs text-slate-500">({attachment.type})</span></p>
            {attachment.type === 'image' && attachment.urlOrContent && (
                 <img src={attachment.urlOrContent} alt={attachment.name} className="max-w-full h-auto max-h-60 rounded-md mt-2 shadow-sm border border-slate-300"/>
            )}
            {(attachment.type === 'code' || attachment.type === 'text' || attachment.type === 'diagram') && attachment.urlOrContent && (
                 attachment.urlOrContent.startsWith('http') ? 
                 <a href={attachment.urlOrContent} target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:text-indigo-800 hover:underline block mt-2 break-all" title={attachment.urlOrContent}>عرض المرفق (رابط خارجي)</a>
                 : <pre className="mt-2 p-3 bg-white rounded-md text-xs whitespace-pre-wrap border border-slate-200 max-h-40 overflow-auto"><code>{attachment.urlOrContent}</code></pre>
            )}
        </div>
    );
};


const ExamQuestionView: React.FC<ExamQuestionViewProps> = ({
  question,
  questionIndex,
  totalQuestions,
  selectedOptionId,
  onOptionSelect,
}) => {
  return (
    <div className="bg-white p-6 sm:p-8 rounded-xl shadow-xl mb-8 border-t-4 border-indigo-500">
      <div className="flex justify-between items-baseline mb-3">
        <p className="text-sm text-slate-500">
            السؤال {questionIndex + 1} من {totalQuestions}
        </p>
        {/* Marks display removed as question.marks is removed. Each question is 1 point. */}
        {/* <p className="text-sm font-medium text-indigo-600 bg-indigo-100 px-2 py-0.5 rounded-full">
            العلامة: {question.marks} 
        </p> */}
      </div>
      <h3 className="text-xl font-semibold text-slate-800 mb-5 leading-relaxed">{question.text}</h3>

      {question.attachments && question.attachments.length > 0 && (
        <div className="mb-5">
          {question.attachments.map(att => <AttachmentDisplay key={att.id} attachment={att} />)}
        </div>
      )}

      <div className="space-y-4">
        {question.options.map((option, index) => (
          <label
            key={option.id}
            className={`flex items-center p-4 border rounded-lg cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-[1.02] hover:shadow-md
              ${selectedOptionId === option.id 
                ? 'bg-indigo-600 border-indigo-700 text-white shadow-lg scale-[1.03]' 
                : 'bg-slate-50 hover:bg-indigo-100 border-slate-300 text-slate-700 hover:border-indigo-300'}`}
            htmlFor={`q-${question.id}-opt-${option.id}`}
          >
            <input
              type="radio"
              id={`q-${question.id}-opt-${option.id}`}
              name={`question-${question.id}`}
              value={option.id}
              checked={selectedOptionId === option.id}
              onChange={() => onOptionSelect(question.id, option.id)}
              className="form-radio h-5 w-5 text-indigo-600 focus:ring-indigo-500 border-gray-300 opacity-0 absolute" // Hidden but accessible
            />
            <span className={`mr-3 h-6 w-6 flex-shrink-0 rounded-full border-2 flex items-center justify-center 
                ${selectedOptionId === option.id ? 'border-white bg-white' : 'border-slate-400 bg-white group-hover:border-indigo-400'}`}>
                {selectedOptionId === option.id && (
                    <svg className="h-4 w-4 text-indigo-600" viewBox="0 0 20 20" fill="currentColor">
                        <circle cx="10" cy="10" r="6" />
                    </svg>
                )}
            </span>
            <span className="text-md flex-grow">{option.text}</span>
             {selectedOptionId === option.id && (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 text-white ml-3 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
            )}
          </label>
        ))}
      </div>
    </div>
  );
};

export default ExamQuestionView;
