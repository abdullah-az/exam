
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { APP_NAME } from '../../constants';
import { UserRole } from '../../types';
import Button from '../shared/Button';

const Header: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  // Generic book/logo icon for header
  const PlatformLogo = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 mr-2 text-sky-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v11.494m0 0A7.5 7.5 0 0019.5 12H4.5a7.5 7.5 0 007.5 5.747zM12 6.253A7.5 7.5 0 004.5 12h15a7.5 7.5 0 00-7.5-5.747z" />
    </svg>
  );


  return (
    <header className="bg-slate-800 text-slate-100 shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link to="/" className="text-xl sm:text-2xl font-bold hover:text-sky-300 transition-colors flex items-center">
          <PlatformLogo />
          {APP_NAME}
        </Link>
        <nav className="flex items-center space-x-2 sm:space-x-3 md:space-x-4 space-x-reverse">
          {user && (
            <>
              {user.role === UserRole.ADMIN && (
                <>
                  <Link to="/admin/questions" className="text-slate-200 hover:text-sky-300 px-2 py-2 sm:px-3 rounded-lg text-sm font-medium transition-colors">إدارة الأسئلة</Link>
                  <Link to="/admin/users" className="text-slate-200 hover:text-sky-300 px-2 py-2 sm:px-3 rounded-lg text-sm font-medium transition-colors">إدارة المستخدمين</Link>
                </>
              )}
              {user.role === UserRole.STUDENT && (
                <>
                  <Link to="/student" className="text-slate-200 hover:text-sky-300 px-2 py-2 sm:px-3 rounded-lg text-sm font-medium transition-colors">الرئيسية</Link>
                  <Link to="/student/exam/take" className="text-slate-200 hover:text-sky-300 px-2 py-2 sm:px-3 rounded-lg text-sm font-medium transition-colors">بدء امتحان</Link>
                </>
              )}
              <span className="text-sm text-slate-300 hidden md:inline whitespace-nowrap">مرحباً, {user.username}</span>
              <Button onClick={handleLogout} variant="secondary" size="sm" className="!px-2.5 !py-1 sm:!px-3 sm:!py-1.5 text-xs sm:text-sm">تسجيل الخروج</Button>
            </>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Header;