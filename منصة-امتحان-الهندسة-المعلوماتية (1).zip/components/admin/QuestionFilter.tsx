
import React, { useState, useEffect } from 'react';
import { Specialization, QuestionFilterCriteria } from '../../types';
import { SPECIALIZATIONS } from '../../constants';
import Select from '../shared/Select';
import Input from '../shared/Input';
import Button from '../shared/Button';

interface QuestionFilterProps {
  onFilterChange: (filters: QuestionFilterCriteria) => void;
  initialFilters?: QuestionFilterCriteria;
}

const QuestionFilter: React.FC<QuestionFilterProps> = ({ onFilterChange, initialFilters = {} }) => {
  const [filters, setFilters] = useState<QuestionFilterCriteria>({
    specialization: initialFilters.specialization || '',
    source: initialFilters.source || '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value as any })); 
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onFilterChange(filters);
  };

  const handleReset = () => {
    const defaultFilters: QuestionFilterCriteria = { specialization: '', source: '' };
    setFilters(defaultFilters);
    onFilterChange(defaultFilters);
  };

  const specializationOptions = [
    { value: '', label: 'كل التخصصات' },
    ...SPECIALIZATIONS.map(spec => ({ value: spec, label: spec }))
  ];

  const sourceOptions = [
    { value: '', label: 'كل المصادر' },
    { value: 'manual', label: 'يدوي فقط' },
    { value: 'ai', label: 'مولّد بـAI فقط' },
  ];

  return (
    <form onSubmit={handleSubmit} className="bg-white p-5 rounded-xl shadow-lg mb-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-4 items-end">
        <Select
          label="التخصص"
          name="specialization"
          options={specializationOptions}
          value={filters.specialization || ''}
          onChange={handleInputChange}
          containerClassName="mb-0"
        />
        <Select
          label="مصدر السؤال"
          name="source"
          options={sourceOptions}
          value={filters.source || ''}
          onChange={handleInputChange}
          containerClassName="mb-0"
        />
        <div className="md:col-span-2 lg:col-span-2 flex space-x-3 space-x-reverse pt-4 md:pt-0 justify-start md:justify-end">
            <Button type="submit" variant="primary" size="md">بحث</Button>
            <Button type="button" variant="neutral" size="md" onClick={handleReset}>إعادة تعيين</Button>
        </div>
      </div>
    </form>
  );
};

export default QuestionFilter;