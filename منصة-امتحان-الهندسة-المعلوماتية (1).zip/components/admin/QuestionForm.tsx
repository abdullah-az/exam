
import React, { useState, useEffect } from 'react';
import { Question, Specialization, NewQuestionData, EditQuestionData, QuestionFormData, QuestionOption } from '../../types';
import { SPECIALIZATIONS, ATTACHMENT_TYPES, INITIAL_QUESTION_FORM_DATA_AR } from '../../constants';
import Button from '../shared/Button';
import Input from '../shared/Input';
import Textarea from '../shared/Textarea';
import Select from '../shared/Select';

interface QuestionFormProps {
  onSubmit: (data: NewQuestionData | EditQuestionData) => void;
  initialData?: Question | null;
  onCancel: () => void;
}

const QuestionForm: React.FC<QuestionFormProps> = ({ onSubmit, initialData, onCancel }) => {
  const [formData, setFormData] = useState<QuestionFormData>(INITIAL_QUESTION_FORM_DATA_AR);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    if (initialData) {
      const correctOptIndex = initialData.options.findIndex(opt => opt.id === initialData.correctOptionId);
      setFormData({
        id: initialData.id,
        text: initialData.text,
        specialization: initialData.specialization,
        option1Text: initialData.options[0]?.text || '',
        option2Text: initialData.options[1]?.text || '',
        option3Text: initialData.options[2]?.text || '',
        option4Text: initialData.options[3]?.text || '',
        correctOptionIndex: correctOptIndex !== -1 ? correctOptIndex.toString() : "0",
        attachmentName: initialData.attachments[0]?.name || '',
        attachmentType: initialData.attachments[0]?.type || '',
        attachmentUrlOrContent: initialData.attachments[0]?.urlOrContent || '',
      });
    } else {
      setFormData(INITIAL_QUESTION_FORM_DATA_AR);
    }
  }, [initialData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!formData.text.trim() || !formData.option1Text.trim() || !formData.option2Text.trim() || !formData.option3Text.trim() || !formData.option4Text.trim()) {
      setFormError("نص السؤال وجميع الخيارات مطلوبة.");
      return;
    }

    const options: QuestionOption[] = [
      { id: initialData?.options[0]?.id || `opt-${Date.now()}-1`, text: formData.option1Text.trim() },
      { id: initialData?.options[1]?.id || `opt-${Date.now()}-2`, text: formData.option2Text.trim() },
      { id: initialData?.options[2]?.id || `opt-${Date.now()}-3`, text: formData.option3Text.trim() },
      { id: initialData?.options[3]?.id || `opt-${Date.now()}-4`, text: formData.option4Text.trim() },
    ];

    const correctOptionId = options[parseInt(formData.correctOptionIndex)].id;

    const attachments = [];
    if (formData.attachmentName.trim() && formData.attachmentType && formData.attachmentUrlOrContent.trim()) {
      attachments.push({
        // For existing attachments, ensure their original ID is preserved if initialData and its attachment exist
        id: initialData?.attachments[0]?.id ? initialData.attachments[0].id : `att-${Date.now()}`,
        name: formData.attachmentName.trim(),
        type: formData.attachmentType as 'image' | 'code' | 'diagram' | 'text',
        urlOrContent: formData.attachmentUrlOrContent.trim(),
      });
    }
    
    const questionPayloadBase = {
      text: formData.text.trim(),
      specialization: formData.specialization,
      options,
      correctOptionId,
      attachments,
      isAIGenerated: false, // Manually added/edited questions are not AI-generated
    };

    if (formData.id) { // Editing existing question
      onSubmit({ ...questionPayloadBase, id: formData.id });
    } else { // Adding new question
      // Type assertion for NewQuestionData, which omits 'id' but includes 'isAIGenerated'
      onSubmit(questionPayloadBase as NewQuestionData);
    }
  };

  const specializationOptions = SPECIALIZATIONS.map(spec => ({ value: spec, label: spec }));
  const attachmentTypeOptions = [{value: "", label: "اختر نوع المرفق (اختياري)"}, ...ATTACHMENT_TYPES.map(type => ({ value: type, label: type }))];
  const correctOptionChoices = [
    {value: "0", label: "الخيار الأول صحيح"},
    {value: "1", label: "الخيار الثاني صحيح"},
    {value: "2", label: "الخيار الثالث صحيح"},
    {value: "3", label: "الخيار الرابع صحيح"},
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-6 p-1" noValidate>
      {formError && <div className="p-3 bg-red-100 text-red-700 rounded-lg text-sm font-medium">{formError}</div>}
      
      <Textarea name="text" label="نص السؤال" value={formData.text} onChange={handleChange} required aria-required="true" rows={3} />
      
      <div className="grid grid-cols-1 md:grid-cols-1 gap-x-6 gap-y-4"> 
        <Select name="specialization" label="التخصص" value={formData.specialization} onChange={handleChange} options={specializationOptions} required aria-required="true" />
      </div>

      <fieldset className="border border-slate-300 p-4 rounded-lg">
        <legend className="text-md font-semibold text-indigo-700 px-2">الخيارات والإجابة الصحيحة</legend>
        <div className="space-y-4 mt-2">
            <Input name="option1Text" label="الخيار 1" value={formData.option1Text} onChange={handleChange} required aria-required="true" containerClassName="mb-2" />
            <Input name="option2Text" label="الخيار 2" value={formData.option2Text} onChange={handleChange} required aria-required="true" containerClassName="mb-2" />
            <Input name="option3Text" label="الخيار 3" value={formData.option3Text} onChange={handleChange} required aria-required="true" containerClassName="mb-2" />
            <Input name="option4Text" label="الخيار 4" value={formData.option4Text} onChange={handleChange} required aria-required="true" containerClassName="mb-2" />
            <Select name="correctOptionIndex" label="الإجابة الصحيحة" value={formData.correctOptionIndex} onChange={handleChange} options={correctOptionChoices} required aria-required="true" />
        </div>
      </fieldset>


      <fieldset className="border border-slate-300 p-4 rounded-lg">
        <legend className="text-md font-semibold text-indigo-700 px-2">المرفق (اختياري)</legend>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-x-6 gap-y-4 mt-2">
            <Input name="attachmentName" label="اسم المرفق" value={formData.attachmentName} onChange={handleChange} containerClassName="mb-0 md:col-span-1"/>
            <Select name="attachmentType" label="نوع المرفق" value={formData.attachmentType} onChange={handleChange} options={attachmentTypeOptions} containerClassName="mb-0 md:col-span-1"/>
            <Input name="attachmentUrlOrContent" label="رابط أو محتوى المرفق" value={formData.attachmentUrlOrContent} onChange={handleChange} placeholder="URL أو نص الكود/الوصف" containerClassName="mb-0 md:col-span-1"/>
        </div>
         {formData.attachmentType === 'image' && formData.attachmentUrlOrContent && (
            <div className="mt-3">
            <p className="text-sm text-slate-600 mb-1">معاينة الصورة:</p>
            <img src={formData.attachmentUrlOrContent} alt={formData.attachmentName || "معاينة المرفق"} className="max-w-xs max-h-40 border rounded-lg shadow-sm"/>
            </div>
        )}
         {formData.attachmentType === 'code' && formData.attachmentUrlOrContent && (
            <div className="mt-3">
            <p className="text-sm text-slate-600 mb-1">معاينة الكود:</p>
            <pre className="bg-slate-50 p-3 rounded-lg text-sm border border-slate-200 max-h-40 overflow-auto"><code>{formData.attachmentUrlOrContent}</code></pre>
            </div>
        )}
      </fieldset>


      <div className="flex justify-end space-x-3 space-x-reverse pt-4">
        <Button type="button" variant="neutral" onClick={onCancel}>إلغاء</Button>
        <Button type="submit" variant="primary">{formData.id ? 'تحديث السؤال' : 'إضافة السؤال'}</Button>
      </div>
    </form>
  );
};

export default QuestionForm;