
export enum Specialization {
  SOFTWARE_ENGINEERING = "هندسة البرمجيات",
  NETWORK_ENGINEERING = "هندسة الشبكات",
  ARTIFICIAL_INTELLIGENCE = "الذكاء الاصطناعي",
  GENERAL = "عام",
}

export enum UserRole {
  ADMIN = "مدير",
  STUDENT = "طالب",
}

export enum ExamType {
  REGULAR = "اعتيادي",
  SMART = "ذكي",
}

export interface User {
  id: string;
  username: string;
  role: UserRole;
  password?: string; // Password should ideally not be stored plaintext or sent to client
}

export interface Attachment {
  id: string;
  name: string;
  type: 'image' | 'code' | 'diagram' | 'text';
  urlOrContent: string; // URL for images, or text content for code/text
}

export interface QuestionOption {
  id: string;
  text: string;
}

export interface Question {
  id: string;
  text: string;
  specialization: Specialization;
  options: QuestionOption[]; // Should always have 4 options
  correctOptionId: string;
  attachments: Attachment[];
  isAIGenerated?: boolean; // To distinguish AI-generated questions
}

export interface ExamAnswer {
  questionId: string;
  selectedOptionId?: string;
}

export interface ExamAttempt {
  id: string;
  userId: string;
  specialization: Specialization;
  examType: ExamType; // Added to distinguish exam mode
  questions: Question[]; // The actual questions presented in this attempt
  answers: ExamAnswer[];
  score: number; // Number of correct answers
  totalMarks: number; // Total number of questions
  submittedAt: string; // ISO date string
}

export type NewQuestionData = Omit<Question, 'id' | 'attachments' | 'isAIGenerated'> & {
  attachments: Array<Omit<Attachment, 'id'>>;
  isAIGenerated?: boolean; 
};
export type EditQuestionData = Question;

// For forms, to handle option text directly
export interface QuestionFormData {
  id?: string;
  text: string;
  specialization: Specialization;
  option1Text: string;
  option2Text: string;
  option3Text: string;
  option4Text: string;
  correctOptionIndex: string; // "0", "1", "2", "3"
  // Simplified attachments for form
  attachmentName: string;
  attachmentType: 'image' | 'code' | 'diagram' | 'text' | '';
  attachmentUrlOrContent: string;
}

export interface QuestionFilterCriteria {
  specialization?: Specialization | '';
  source?: 'manual' | 'ai' | ''; // Added to filter by question source
}