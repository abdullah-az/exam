
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Question, Specialization, QuestionOption } from '../types';
import { MAX_SAMPLE_QUESTIONS_TO_SEND_TO_AI } from "../constants";

// Ensure API_KEY is available in the environment.
// The application code MUST NOT provide a UI for API key input.
const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  console.error("API_KEY for Gemini is not set in environment variables. Smart exam feature will not work.");
}
const ai = new GoogleGenAI({ apiKey: API_KEY! });
const modelName = 'gemini-2.5-flash-preview-04-17';

interface AIQuestionResponse {
  text: string;
  options: string[];
  correctOptionIndex: number;
}

function parseAndCleanJson(jsonString: string): any {
  let cleanJsonString = jsonString.trim();
  const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
  const match = cleanJsonString.match(fenceRegex);
  if (match && match[2]) {
    cleanJsonString = match[2].trim();
  }
  try {
    return JSON.parse(cleanJsonString);
  } catch (e) {
    console.error("Failed to parse JSON from AI response:", e, "Original string:", jsonString);
    throw new Error("فشل في تحليل استجابة الذكاء الاصطناعي كـ JSON.");
  }
}


export const generateSmartQuestions = async (
  specialization: Specialization,
  numQuestions: number,
  sampleQuestions: Question[]
): Promise<Question[]> => {
  if (!API_KEY) {
    throw new Error("API Key for Gemini not configured. Cannot generate smart questions.");
  }

  const limitedSampleQuestions = sampleQuestions.slice(0, MAX_SAMPLE_QUESTIONS_TO_SEND_TO_AI);

  const samplePromptPart = limitedSampleQuestions.length > 0 ?
    `The questions should be similar in style, topic, and difficulty to the following examples from the "${specialization}" specialization:
${limitedSampleQuestions.map(q => `
- Question: ${q.text}
  Options: ${q.options.map((opt, i) => `${i + 1}. ${opt.text}`).join('; ')}
  Correct Option Example (index based on your format): ${q.options.findIndex(opt => opt.id === q.correctOptionId)} 
`).join('\n')}
` : `Please generate questions for the "${specialization}" specialization. Since no samples are provided, use general knowledge for this field.`;


  const prompt = `
You are an AI assistant specialized in creating educational content for Information Engineering exams in Arabic.
Your task is to generate ${numQuestions} new and distinct multiple-choice exam questions.

${samplePromptPart}

Please generate ${numQuestions} unique questions. Each question must:
1. Be in ARABIC.
2. Have a clear question text related to ${specialization}.
3. Include exactly four distinct answer options, also in Arabic.
4. The correct answer must be one of these four options.
5. Be of a typical exam difficulty for a university-level Information Engineering student.

Return your response *only* as a valid JSON array of objects. Each object in the array must strictly follow this structure:
{
  "text": "نص السؤال باللغة العربية",
  "options": [
    "النص للخيار الأول",
    "النص للخيار الثاني",
    "النص للخيار الثالث",
    "النص للخيار الرابع"
  ],
  "correctOptionIndex": <integer from 0 to 3, where 0 is the first option>
}

Ensure the JSON is well-formed and can be directly parsed. Do not include any explanations, introductory text, or markdown code fences like \`\`\`json or \`\`\` around the JSON array itself.
The entire response should be the JSON array.
`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: modelName,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const aiResponseArray: AIQuestionResponse[] = parseAndCleanJson(response.text);

    if (!Array.isArray(aiResponseArray)) {
        console.error("AI response is not an array:", aiResponseArray);
        throw new Error("لم يتم إرجاع قائمة أسئلة صالحة من الذكاء الاصطناعي.");
    }
    
    const generatedQuestions: Question[] = aiResponseArray.map((aiQ, index) => {
      if (!aiQ.text || !Array.isArray(aiQ.options) || aiQ.options.length !== 4 || typeof aiQ.correctOptionIndex !== 'number' || aiQ.correctOptionIndex < 0 || aiQ.correctOptionIndex > 3) {
        console.warn("Skipping malformed AI question object:", aiQ);
        return null; 
      }

      const questionId = `q-ai-${Date.now()}-${Math.random().toString(36).substr(2, 7)}-${index}`; // More robust temp ID
      const options: QuestionOption[] = aiQ.options.map((optText, optIndex) => ({
        id: `${questionId}-opt-${optIndex}`,
        text: optText,
      }));
      const correctOptionId = options[aiQ.correctOptionIndex].id;

      return {
        id: questionId, // This ID is temporary for the current exam session if saving fails; DataContext will assign a new one on save.
        text: aiQ.text,
        specialization: specialization,
        options: options,
        correctOptionId: correctOptionId,
        attachments: [],
        isAIGenerated: true, // Mark as AI-generated
      };
    }).filter(q => q !== null) as Question[];

    if (generatedQuestions.length === 0 && numQuestions > 0 && aiResponseArray.length > 0) {
      throw new Error("تم إنشاء أسئلة غير صالحة بواسطة الذكاء الاصطناعي. حاول مرة أخرى أو تحقق من إعدادات النموذج.");
    }
    if (generatedQuestions.length < numQuestions) {
      console.warn(`AI generated ${generatedQuestions.length} questions, but ${numQuestions} were requested.`);
      if (generatedQuestions.length === 0) {
        throw new Error("فشل الذكاء الاصطناعي في توليد أي أسئلة صالحة.");
      }
    }

    return generatedQuestions;

  } catch (error) {
    console.error("Error generating smart questions:", error);
    if (error instanceof Error && error.message.includes("API Key")) {
         throw new Error("حدث خطأ في الاتصال بخدمة الذكاء الاصطناعي بسبب مشكلة في مفتاح API. يرجى التأكد من تكوينه بشكل صحيح.");
    }
    throw new Error("حدث خطأ أثناء توليد الأسئلة الذكية. قد يكون السبب مشكلة في الاتصال بالخدمة، أو إعدادات النموذج، أو تجاوز الحصة المسموح بها. يرجى المحاولة لاحقاً أو مراجعة إعدادات الخدمة.");
  }
};