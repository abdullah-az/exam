
import { Question, User, ExamAttempt, Specialization, UserRole, QuestionOption, Attachment, ExamType } from '../types';

export const MOCK_USERS: User[] = [
  { id: 'admin-001', username: 'admin', role: UserRole.ADMIN, password: 'password' },
  { id: 'student-001', username: 'student1', role: UserRole.STUDENT, password: 'password' },
  { id: 'student-002', username: 'طالب2', role: UserRole.STUDENT, password: 'password' },
];

const MOCK_QUESTIONS: Omit<Question, 'id' | 'isAIGenerated'>[] = [ // Mock questions are manual
  {
    text: 'ما هي الوظيفة الرئيسية لبروتوكول HTTP في سياق الويب؟',
    specialization: Specialization.NETWORK_ENGINEERING,
    options: [
      { id: 'q1_opt1', text: 'نقل الملفات بشكل آمن' },
      { id: 'q1_opt2', text: 'إدارة قواعد البيانات' },
      { id: 'q1_opt3', text: 'طلب واستقبال صفحات الويب والموارد' },
      { id: 'q1_opt4', text: 'تشفير البيانات أثناء النقل' },
    ],
    correctOptionId: 'q1_opt3',
    attachments: [],
  },
  {
    text: 'أي من هياكل البيانات التالية يستخدم مبدأ LIFO (Last In, First Out)؟',
    specialization: Specialization.SOFTWARE_ENGINEERING,
    options: [
      { id: 'q2_opt1', text: 'Queue (الطابور)' },
      { id: 'q2_opt2', text: 'Stack (المكدس)' },
      { id: 'q2_opt3', text: 'Linked List (القائمة المتصلة)' },
      { id: 'q2_opt4', text: 'Tree (الشجرة)' },
    ],
    correctOptionId: 'q2_opt2',
    attachments: [
      { id: 'att1', name: 'توضيح LIFO', type: 'diagram', urlOrContent: 'https://picsum.photos/seed/lifo/200/100' }
    ],
  },
  {
    text: 'ما هو الغرض الأساسي من خوارزمية "Decision Tree" في التعلم الآلي؟',
    specialization: Specialization.ARTIFICIAL_INTELLIGENCE,
    options: [
      { id: 'q3_opt1', text: 'تجميع البيانات المتشابهة (Clustering)' },
      { id: 'q3_opt2', text: 'تقليل أبعاد البيانات (Dimensionality Reduction)' },
      { id: 'q3_opt3', text: 'التصنيف والتنبؤ بناءً على مجموعة من القرارات (Classification/Regression)' },
      { id: 'q3_opt4', text: 'اكتشاف الأنماط المتكررة (Association Rule Mining)' },
    ],
    correctOptionId: 'q3_opt3',
    attachments: [],
  },
  {
    text: 'ما هو مفهوم "Encapsulation" في البرمجة الشيئية (OOP)؟',
    specialization: Specialization.SOFTWARE_ENGINEERING,
    options: [
      { id: 'q4_opt1', text: 'وراثة الخصائص من كائن آخر' },
      { id: 'q4_opt2', text: 'إخفاء تفاصيل التنفيذ الداخلية للكائن وعرض واجهة بسيطة' },
      { id: 'q4_opt3', text: 'إمكانية الكائن لاتخاذ أشكال متعددة' },
      { id: 'q4_opt4', text: 'تقسيم البرنامج إلى وحدات صغيرة' },
    ],
    correctOptionId: 'q4_opt2',
    attachments: [],
  },
  {
    text: 'ما هو الفرق الرئيسي بين TCP و UDP؟',
    specialization: Specialization.NETWORK_ENGINEERING,
    options: [
        { id: 'q5_opt1', text: 'TCP موجه للاتصال و UDP غير موجه للاتصال' },
        { id: 'q5_opt2', text: 'UDP أسرع دائمًا من TCP' },
        { id: 'q5_opt3', text: 'TCP لا يضمن تسليم البيانات' },
        { id: 'q5_opt4', text: 'UDP يستخدم لتصفح الويب الآمن' },
    ],
    correctOptionId: 'q5_opt1',
    attachments: [],
  },
  {
    text: 'ما هو نوع من أنواع التعلم الآلي الذي يتضمن تدريب نموذج على بيانات غير مصنفة؟',
    specialization: Specialization.ARTIFICIAL_INTELLIGENCE,
    options: [
        { id: 'q6_opt1', text: 'التعلم المراقب (Supervised Learning)' },
        { id: 'q6_opt2', text: 'التعلم غير المراقب (Unsupervised Learning)' },
        { id: 'q6_opt3', text: 'التعلم المعزز (Reinforcement Learning)' },
        { id: 'q6_opt4', text: 'التعلم شبه المراقب (Semi-supervised Learning)' },
    ],
    correctOptionId: 'q6_opt2',
    attachments: [],
  },
  {
    text: 'أي مما يلي يعتبر مثالاً على لغة برمجة مُفسَّرة (Interpreted Language)؟',
    specialization: Specialization.GENERAL,
    options: [
        { id: 'q7_opt1', text: 'C++' },
        { id: 'q7_opt2', text: 'Java' },
        { id: 'q7_opt3', text: 'Python' },
        { id: 'q7_opt4', text: 'C#' },
    ],
    correctOptionId: 'q7_opt3',
    attachments: [],
  }
];

const MOCK_EXAM_ATTEMPTS: ExamAttempt[] = [];

export const getInitialQuestions = (): Question[] => {
  const stored = localStorage.getItem('questions');
  if (stored) {
    try {
      const parsedQuestions = JSON.parse(stored) as Array<Question & { year?: any; marks?: any }>;
      const migratedQuestions = parsedQuestions.map(q => {
          const { year, marks, ...rest } = q;
          return { ...rest, isAIGenerated: q.isAIGenerated || false }; // Ensure isAIGenerated defaults to false
      });
      return migratedQuestions;
    } catch (e) {
      console.error("Failed to parse questions from localStorage", e);
      localStorage.removeItem('questions'); 
    }
  }
  
  const initialQuestionsWithIds: Question[] = MOCK_QUESTIONS.map((q, index) => ({
    ...q,
    id: `q${index + 1}`, // Ensure consistent IDs for mock options
    options: q.options.map((opt, optIndex) => ({ ...opt, id: `q${index + 1}_opt${optIndex + 1}` })), // Ensure options have consistent IDs based on question ID
    correctOptionId: `q${index + 1}_opt${q.options.findIndex(opt => opt.id === q.correctOptionId) +1 }`, // This logic for correctOptionId might be flawed if original IDs were specific
    isAIGenerated: false, // Explicitly set for mock data
  }));

  // Re-map correctOptionId based on newly generated option IDs
  const finalInitialQuestions = initialQuestionsWithIds.map(q => {
    const correctOptText = MOCK_QUESTIONS[parseInt(q.id.substring(1)) -1].options.find(o => o.id === MOCK_QUESTIONS[parseInt(q.id.substring(1)) -1].correctOptionId)?.text;
    const newCorrectOpt = q.options.find(opt => opt.text === correctOptText);
    return {
        ...q,
        correctOptionId: newCorrectOpt ? newCorrectOpt.id : q.options[0].id // Fallback if text matching fails, shouldn't happen with current data
    };
  });


  localStorage.setItem('questions', JSON.stringify(finalInitialQuestions));
  return finalInitialQuestions;
};

export const getInitialUsers = (): User[] => {
  const stored = localStorage.getItem('users');
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch (e) {
      console.error("Failed to parse users from localStorage", e);
      localStorage.removeItem('users');
    }
  }
  localStorage.setItem('users', JSON.stringify(MOCK_USERS));
  return MOCK_USERS;
};

export const getInitialExamAttempts = (): ExamAttempt[] => {
    const stored = localStorage.getItem('examAttempts');
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch (e) {
        console.error("Failed to parse exam attempts from localStorage", e);
        localStorage.removeItem('examAttempts');
      }
    }
    localStorage.setItem('examAttempts', JSON.stringify(MOCK_EXAM_ATTEMPTS));
    return MOCK_EXAM_ATTEMPTS;
};