
import React, { createContext, useState, useContext, useEffect, ReactNode, useCallback } from 'react';
import { Question, ExamAttempt, NewQuestionData, EditQuestionData, QuestionFilterCriteria } from '../types';
import { getInitialQuestions, getInitialUsers, getInitialExamAttempts } from '../services/mockDataService';

interface DataContextType {
  questions: Question[];
  addQuestion: (questionData: NewQuestionData) => Question;
  updateQuestion: (questionData: EditQuestionData) => Question | null;
  deleteQuestion: (questionId: string) => void;
  getQuestionById: (questionId: string) => Question | undefined;
  getFilteredQuestions: (filters: QuestionFilterCriteria) => Question[];
  
  examAttempts: ExamAttempt[];
  addExamAttempt: (attempt: ExamAttempt) => void;
  getExamAttemptById: (attemptId: string) => ExamAttempt | undefined;
  getExamAttemptsByUserId: (userId: string) => ExamAttempt[];
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [questions, setQuestions] = useState<Question[]>(() => {
    // Initial load already handles migration in mockDataService
    return getInitialQuestions();
  });

  const [examAttempts, setExamAttempts] = useState<ExamAttempt[]>(() => {
    const storedAttempts = localStorage.getItem('examAttempts');
    return storedAttempts ? JSON.parse(storedAttempts) : getInitialExamAttempts();
  });

  useEffect(() => {
    localStorage.setItem('questions', JSON.stringify(questions));
  }, [questions]);

  useEffect(() => {
    localStorage.setItem('examAttempts', JSON.stringify(examAttempts));
  }, [examAttempts]);
  
  // Initialize users in localStorage if not already there.
  // This context isn't primarily for users, but good to ensure data consistency.
  useEffect(() => {
    if (!localStorage.getItem('users')) {
      localStorage.setItem('users', JSON.stringify(getInitialUsers()));
    }
  }, []);

  const addQuestion = useCallback((questionData: NewQuestionData): Question => {
    const newQuestion: Question = {
      ...questionData, // Spreading questionData first
      id: `q-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      attachments: questionData.attachments.map(att => ({...att, id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`})),
      isAIGenerated: questionData.isAIGenerated || false, // Default to false if not provided
    };
    setQuestions(prev => [newQuestion, ...prev]);
    return newQuestion;
  }, []);

  const updateQuestion = useCallback((questionData: EditQuestionData): Question | null => {
    let updatedQuestion: Question | null = null;
    setQuestions(prev => prev.map(q => {
      if (q.id === questionData.id) {
        // When updating, ensure isAIGenerated is preserved or explicitly set
        updatedQuestion = { ...questionData, isAIGenerated: questionData.isAIGenerated || false };
        return updatedQuestion;
      }
      return q;
    }));
    return updatedQuestion;
  }, []);

  const deleteQuestion = useCallback((questionId: string) => {
    setQuestions(prev => prev.filter(q => q.id !== questionId));
  }, []);

  const getQuestionById = useCallback((questionId: string): Question | undefined => {
    return questions.find(q => q.id === questionId);
  }, [questions]);

  const getFilteredQuestions = useCallback((filters: QuestionFilterCriteria): Question[] => {
    return questions.filter(q => {
      const specMatch = !filters.specialization || q.specialization === filters.specialization;
      const sourceMatch = !filters.source || 
                          (filters.source === 'manual' && !q.isAIGenerated) ||
                          (filters.source === 'ai' && q.isAIGenerated);
      return specMatch && sourceMatch;
    });
  }, [questions]);

  const addExamAttempt = useCallback((attempt: ExamAttempt) => {
    setExamAttempts(prev => [attempt, ...prev]);
  }, []);

  const getExamAttemptById = useCallback((attemptId: string): ExamAttempt | undefined => {
    return examAttempts.find(att => att.id === attemptId);
  }, [examAttempts]);

  const getExamAttemptsByUserId = useCallback((userId: string): ExamAttempt[] => {
    return examAttempts.filter(att => att.userId === userId).sort((a,b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime());
  }, [examAttempts]);

  return (
    <DataContext.Provider value={{ 
      questions, addQuestion, updateQuestion, deleteQuestion, getQuestionById, getFilteredQuestions,
      examAttempts, addExamAttempt, getExamAttemptById, getExamAttemptsByUserId
    }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = (): DataContextType => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};