
import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { User, UserRole } from '../types';
import { MOCK_USERS } from '../services/mockDataService'; // Import mock users

interface AuthContextType {
  user: User | null;
  login: (username: string, password_unused: string) => boolean; // Password check is mocked
  logout: () => void;
  registerStudent: (username: string, password_unused: string) => User | null; // Mock registration
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const storedUser = localStorage.getItem('currentUser');
    return storedUser ? JSON.parse(storedUser) : null;
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem('currentUser', JSON.stringify(user));
    } else {
      localStorage.removeItem('currentUser');
    }
  }, [user]);

  const login = (username: string, password_unused: string): boolean => {
    // In a real app, this would involve an API call and password hashing.
    // For this mock, we'll just find a user by username from MOCK_USERS.
    const foundUser = MOCK_USERS.find(u => u.username === username);
    if (foundUser) {
      setUser(foundUser);
      return true;
    }
    // Simple fallback for new users if not found, assign as student (for demo purposes)
    // This part is for easier testing without pre-defining all users in MOCK_USERS
    // In a real scenario, login would fail if user not found or password incorrect.
    // For this example, we'll allow any username to "login" as a student if not admin
    if(username === 'admin') { // only admin login if explicitly admin
        setUser({ id: 'admin-user', username: 'admin', role: UserRole.ADMIN });
        return true;
    } else if (username) {
        // For students, allow any username to "login" or "register" for demo
        const studentUser: User = { id: `student-${Date.now()}`, username, role: UserRole.STUDENT };
        MOCK_USERS.push(studentUser); // Add to mock users list for consistency (not persisted beyond session unless MOCK_USERS is updated)
        localStorage.setItem('users', JSON.stringify(MOCK_USERS)); // Persist updated users list
        setUser(studentUser);
        return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
  };

  const registerStudent = (username: string, password_unused: string): User | null => {
    // Mock registration: check if username exists
    if (MOCK_USERS.find(u => u.username === username)) {
      return null; // Username already exists
    }
    const newStudent: User = {
      id: `student-${Date.now()}`,
      username,
      role: UserRole.STUDENT,
    };
    MOCK_USERS.push(newStudent); // Add to in-memory MOCK_USERS
    localStorage.setItem('users', JSON.stringify(MOCK_USERS)); // Persist updated users list for this session
    setUser(newStudent); // Auto-login after registration
    return newStudent;
  };


  return (
    <AuthContext.Provider value={{ user, login, logout, registerStudent }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};