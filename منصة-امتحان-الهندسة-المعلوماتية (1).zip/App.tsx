
import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';
import Header from './components/layout/Header';
import LoginPage from './pages/LoginPage';
import AdminDashboardPage from './pages/admin/AdminDashboardPage';
import QuestionManagementPage from './pages/admin/QuestionManagementPage';
import UserManagementPage from './pages/admin/UserManagementPage';
import StudentDashboardPage from './pages/student/StudentDashboardPage';
import TakeExamPage from './pages/student/TakeExamPage';
import ExamResultsPage from './pages/student/ExamResultsPage';
import { UserRole } from './types';
import { APP_NAME, SPECIALIZATIONS } from './constants'; 
import { Link } from 'react-router-dom'; // Added for footer links

// Placeholder Social Icons
const FacebookIcon = () => <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24"><path d="M9 8h-3v4h3v12h5V12h3.642L18 8h-4V6.333C14 5.378 14.192 5 15.115 5H18V0h-3.808C10.596 0 9 1.583 9 4.615V8z"/></svg>;
const InstagramIcon = () => <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.85s-.011 3.584-.069 4.85c-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07s-3.584-.012-4.85-.07c-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.85s.012-3.584.07-4.85c.149-3.227 1.664-4.771 4.919-4.919C8.416 2.175 8.796 2.163 12 2.163m0-2.163C8.741 0 8.31 0 .011 7.022.072 4.858.084 4.48.084L12 0zm0 4.865A7.135 7.135 0 1012 19.135 7.135 7.135 0 0012 4.865zm0 10.822A3.688 3.688 0 1112 8.007a3.688 3.688 0 010 7.68zm4.805-9.906a1.148 1.148 0 100-2.296 1.148 1.148 0 000 2.296z"/></svg>;
const TwitterIcon = () => <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg>;
const PlatformFooterLogo = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 mr-2 text-sky-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v11.494m0 0A7.5 7.5 0 0019.5 12H4.5a7.5 7.5 0 007.5 5.747zM12 6.253A7.5 7.5 0 004.5 12h15a7.5 7.5 0 00-7.5-5.747z" />
    </svg>
);


const App: React.FC = () => {
  const { user } = useAuth();

  const AdminRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    if (!user) return <Navigate to="/login" replace />;
    if (user.role !== UserRole.ADMIN) return <Navigate to="/student" replace />;
    return <>{children}</>;
  };

  const StudentRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    if (!user) return <Navigate to="/login" replace />;
    if (user.role !== UserRole.STUDENT) return <Navigate to="/admin" replace />;
    return <>{children}</>;
  };
  
  const AuthenticatedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    if (!user) return <Navigate to="/login" replace />;
    return <>{children}</>;
  };

  return (
    <HashRouter>
      <div className="min-h-screen flex flex-col bg-slate-100">
        {user && <Header />}
        <main className="flex-grow container mx-auto px-4 py-8 lg:py-12">
          <Routes>
            <Route path="/login" element={user ? (user.role === UserRole.ADMIN ? <Navigate to="/admin" /> : <Navigate to="/student" />) : <LoginPage />} />
            
            <Route path="/admin" element={<AdminRoute><AdminDashboardPage /></AdminRoute>} />
            <Route path="/admin/questions" element={<AdminRoute><QuestionManagementPage /></AdminRoute>} />
            <Route path="/admin/users" element={<AdminRoute><UserManagementPage /></AdminRoute>} />
            
            <Route path="/student" element={<StudentRoute><StudentDashboardPage /></StudentRoute>} />
            <Route path="/student/exam/take" element={<StudentRoute><TakeExamPage /></StudentRoute>} />
            <Route path="/student/exam/results/:attemptId" element={<StudentRoute><ExamResultsPage /></StudentRoute>} />
            
            <Route path="/" element={
              <AuthenticatedRoute>
                {user?.role === UserRole.ADMIN ? <Navigate to="/admin" /> : <Navigate to="/student" />}
              </AuthenticatedRoute>
            } />
            <Route path="*" element={<Navigate to={user ? (user.role === UserRole.ADMIN ? "/admin" : "/student") : "/login"} />} />
          </Routes>
        </main>
        
        <footer className="bg-slate-900 text-slate-300 pt-16 pb-8 px-4 sm:px-6 lg:px-8">
          <div className="container mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
              {/* Column 1: Platform Info */}
              <div className="space-y-4">
                <Link to="/" className="flex items-center text-xl font-semibold text-white hover:text-sky-300 transition-colors">
                  <PlatformFooterLogo />
                  {APP_NAME}
                </Link>
                <p className="text-sm leading-relaxed">
                  منصة تعليمية شاملة مصممة لمساعدة طلاب الهندسة المعلوماتية على الاستعداد لامتحاناتهم بكفاءة وثقة.
                </p>
                <div className="flex space-x-4 space-x-reverse">
                  <a href="#" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-sky-400 transition-colors" aria-label="Facebook"><FacebookIcon /></a>
                  <a href="#" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-sky-400 transition-colors" aria-label="Instagram"><InstagramIcon /></a>
                  <a href="#" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-sky-400 transition-colors" aria-label="Twitter"><TwitterIcon /></a>
                </div>
              </div>

              {/* Column 2: Quick Links */}
              <div>
                <h5 className="text-lg font-semibold text-white mb-4">روابط سريعة</h5>
                <ul className="space-y-2 text-sm">
                  <li><Link to="/student" className="hover:text-sky-300 transition-colors">الصفحة الرئيسية</Link></li>
                  {SPECIALIZATIONS.map(spec => (
                     <li key={spec}><Link to="/student/exam/take" className="hover:text-sky-300 transition-colors">{spec}</Link></li>
                  ))}
                  <li><a href="#" className="hover:text-sky-300 transition-colors">المصادر التعليمية (قريباً)</a></li>
                </ul>
              </div>

              {/* Column 3: Contact Us */}
              <div>
                <h5 className="text-lg font-semibold text-white mb-4">تواصل معنا</h5>
                <ul className="space-y-2 text-sm">
                  <li><a href="mailto:support@engineeringexam.com" className="hover:text-sky-300 transition-colors">support@engineeringexam.com</a></li>
                  <li><a href="tel:+1234567890" className="hover:text-sky-300 transition-colors">+123 4567 11 963+</a></li>
                  <li><p>دمشق، سوريا</p></li>
                </ul>
              </div>
              
              {/* Column 4: Placeholder or another set of links */}
               <div>
                <h5 className="text-lg font-semibold text-white mb-4">المزيد</h5>
                <ul className="space-y-2 text-sm">
                    <li><a href="#" className="hover:text-sky-300 transition-colors">حول المنصة</a></li>
                    <li><a href="#" className="hover:text-sky-300 transition-colors">الأسئلة الشائعة</a></li>
                    <li><a href="#" className="hover:text-sky-300 transition-colors">للمساهمين</a></li>
                </ul>
              </div>

            </div>
            <div className="border-t border-slate-700 pt-8 mt-8 text-sm text-center md:flex md:justify-between">
              <p>&copy; {new Date().getFullYear()} {APP_NAME}. جميع الحقوق محفوظة.</p>
              <div className="mt-4 md:mt-0 space-x-4 space-x-reverse">
                <a href="#" className="hover:text-sky-300 transition-colors">شروط الاستخدام</a>
                <a href="#" className="hover:text-sky-300 transition-colors">سياسة الخصوصية</a>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </HashRouter>
  );
};

export default App;
