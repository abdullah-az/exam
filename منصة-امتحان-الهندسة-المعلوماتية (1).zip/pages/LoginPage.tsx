
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { UserRole } from '../types';
import Button from '../components/shared/Button';
import Input from '../components/shared/Input';
import { APP_NAME } from '../constants';

const LoginPage: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState(''); // Password not actually used for mock login
  const [isRegistering, setIsRegistering] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { login, registerStudent } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!username) {
      setError('اسم المستخدم مطلوب.');
      return;
    }
     // Basic password validation for UI feedback, though not used in mock logic
    if (!password) {
      setError('كلمة المرور مطلوبة.');
      return;
    }


    let success = false;
    if (isRegistering) {
      const newUser = registerStudent(username, password);
      if (newUser) {
        success = true;
        if (newUser.role === UserRole.ADMIN) navigate('/admin');
        else navigate('/student');
      } else {
        setError('اسم المستخدم موجود بالفعل أو فشل التسجيل.');
      }
    } else {
      success = login(username, password);
      if (success) {
        // AuthContext will redirect via App.tsx logic based on user role
        // For safety, we can hint based on typical usernames
        if (username.toLowerCase() === 'admin') navigate('/admin');
        else navigate('/student');
      } else {
        setError('فشل تسجيل الدخول. تحقق من اسم المستخدم أو كلمة المرور.');
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white p-8 sm:p-10 rounded-xl shadow-2xl">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-indigo-700">
            {isRegistering ? 'إنشاء حساب جديد' : 'تسجيل الدخول إلى'}
            <br/> 
            <span className="text-indigo-600">{APP_NAME}</span>
          </h2>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {error && <p className="text-sm text-red-700 bg-red-100 p-3 rounded-lg text-center font-medium">{error}</p>}
          <Input
            id="username"
            label="اسم المستخدم"
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="مثال: admin أو student1"
            required
            aria-required="true"
            aria-describedby={error ? "error-message" : undefined}
          />
          <Input
            id="password"
            label="كلمة المرور"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="أدخل كلمة المرور"
            required
            aria-required="true"
             aria-describedby={error ? "error-message" : undefined}
          />
           {error && <span id="error-message" className="sr-only">{error}</span>}

          <Button type="submit" variant="primary" size="lg" className="w-full">
            {isRegistering ? 'تسجيل' : 'تسجيل الدخول'}
          </Button>
        </form>
        <div className="text-sm text-center">
          <button
            onClick={() => { setIsRegistering(!isRegistering); setError(null); }}
            className="font-medium text-indigo-600 hover:text-indigo-500 transition-colors"
          >
            {isRegistering ? 'لديك حساب بالفعل؟ تسجيل الدخول' : 'لا تملك حساباً؟ إنشاء حساب طالب جديد'}
          </button>
        </div>
         <p className="mt-6 text-center text-xs text-slate-500 border-t border-slate-200 pt-4">
          لتجربة دور المدير: استخدم اسم المستخدم `admin`. <br/>
          لتجربة دور الطالب: استخدم أي اسم مستخدم آخر (مثل `student1` أو قم بإنشاء حساب جديد).
        </p>
      </div>
    </div>
  );
};

export default LoginPage;