
import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useData } from '../../contexts/DataContext';
import Button from '../../components/shared/Button'; // Import Button

const AdminDashboardPage: React.FC = () => {
  const { user } = useAuth();
  const { questions, examAttempts } = useData(); 

  if (!user) return null;

  const manualQuestionsCount = questions.filter(q => !q.isAIGenerated).length;
  const aiQuestionsCount = questions.filter(q => q.isAIGenerated).length;
  const totalQuestions = questions.length;
  const totalAttempts = examAttempts.length;
  // const totalUsers = MOCK_USERS.length; // Consider fetching users from localStorage if needed for more accuracy

  const questionStatsNode = (
    <>
      <div className="text-2xl font-bold text-indigo-600 mb-1">
          {manualQuestionsCount} <span className="text-lg font-normal">سؤال يدوي</span>
      </div>
      <div className="text-2xl font-bold text-teal-600 mb-3">
          {aiQuestionsCount} <span className="text-lg font-normal">سؤال مولّد بـAI</span>
      </div>
      <p className="text-sm text-slate-500 -mt-2 mb-2">الإجمالي: {totalQuestions} أسئلة</p>
    </>
  );

  const Card: React.FC<{
    title: string, 
    description: string, 
    linkTo: string, 
    linkText: string, 
    stat?: string, 
    statColor?: string,
    customStatNode?: React.ReactNode 
  }> = ({title, description, linkTo, linkText, stat, statColor = "text-indigo-600", customStatNode}) => (
    <div className="bg-white p-6 rounded-xl shadow-xl hover:shadow-2xl transition-all duration-300 ease-in-out flex flex-col">
      <h2 className="text-xl font-semibold text-indigo-700 mb-2">{title}</h2>
      {customStatNode ? <div className="my-2">{customStatNode}</div> : (stat && <p className={`text-3xl font-bold ${statColor} mb-3`}>{stat}</p>)}
      <p className="text-slate-600 mb-4 flex-grow">{description}</p>
      <Link to={linkTo}>
        <Button variant="primary" size="sm" className="w-full sm:w-auto">
            {linkText} &rarr;
        </Button>
      </Link>
    </div>
  );

  return (
    <div className="space-y-10">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-indigo-800">لوحة تحكم المدير</h1>
        <p className="text-xl text-slate-600 mt-2">مرحباً بك, <span className="font-semibold text-indigo-600">{user.username}</span>! هنا يمكنك إدارة المنصة بفعالية.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <Card 
          title="إدارة الأسئلة"
          customStatNode={questionStatsNode}
          description="إضافة وتعديل وحذف أسئلة الامتحانات اليدوية والمولدة بواسطة الذكاء الاصطناعي."
          linkTo="/admin/questions"
          linkText="الانتقال إلى إدارة الأسئلة"
        />
        <Card 
          title="إدارة المستخدمين"
          description="عرض وإدارة حسابات المستخدمين (الطلاب والمشرفين)."
          linkTo="/admin/users"
          linkText="الانتقال إلى إدارة المستخدمين"
          // stat={`${totalUsers} مستخدم`} // Placeholder for user count
        />
        <Card 
          title="إحصائيات الامتحانات"
          description="نظرة عامة على نشاط الامتحانات."
          linkTo="#" // Future link to detailed stats
          linkText="عرض الإحصائيات (قريباً)"
          stat={`${totalAttempts} محاولة`}
          statColor="text-green-600"
        />
      </div>
       <div className="bg-white p-6 rounded-xl shadow-xl mt-8">
        <h3 className="text-xl font-semibold text-indigo-700 mb-3">نصائح سريعة</h3>
        <ul className="list-disc list-inside space-y-1 text-slate-600">
          <li>تأكد من مراجعة الأسئلة بانتظام لضمان جودتها، خاصة تلك المولدة بالـAI.</li>
          <li>استخدم الفلاتر في صفحة الأسئلة لتسهيل البحث والعرض حسب مصدر السؤال.</li>
          <li>قم بتحديث قائمة المستخدمين عند الحاجة.</li>
        </ul>
      </div>
    </div>
  );
};

export default AdminDashboardPage;