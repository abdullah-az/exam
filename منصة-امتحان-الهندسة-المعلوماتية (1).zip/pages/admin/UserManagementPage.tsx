
import React, { useState, useEffect } from 'react';
import { User, UserRole } from '../../types';
import Button from '../../components/shared/Button';
import Modal from '../../components/shared/Modal';
import Input from '../../components/shared/Input';
import Select from '../../components/shared/Select';
import { USER_ROLES } from '../../constants';
import { useAuth } from '../../contexts/AuthContext'; // Import useAuth to get current user

const UserManagementPage: React.FC = () => {
  const { user: currentUser } = useAuth(); // Get current logged-in user
  const [users, setUsers] = useState<User[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [formData, setFormData] = useState<{ username: string; role: UserRole; password?: string }>({ username: '', role: UserRole.STUDENT, password: '' });
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');


  useEffect(() => {
    const storedUsers = localStorage.getItem('users');
    if (storedUsers) {
      setUsers(JSON.parse(storedUsers));
    }
  }, []);

  const saveUsers = (updatedUsers: User[]) => {
    localStorage.setItem('users', JSON.stringify(updatedUsers));
    setUsers(updatedUsers);
  };

  const handleOpenModal = (user?: User) => {
    if (user) {
      setEditingUser(user);
      setFormData({ username: user.username, role: user.role, password: '' }); // Don't prefill password for edit
    } else {
      setEditingUser(null);
      setFormData({ username: '', role: UserRole.STUDENT, password: '' });
    }
    setError(null);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingUser(null);
    setError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!formData.username.trim()) {
      setError("اسم المستخدم مطلوب.");
      return;
    }
    if (!editingUser && !formData.password?.trim()) { 
        setError("كلمة المرور مطلوبة للمستخدم الجديد.");
        return;
    }
    if (formData.password && formData.password.trim().length < 6 && !editingUser) {
        setError("كلمة المرور يجب أن تكون 6 أحرف على الأقل.");
        return;
    }
    // Prevent editing admin username to something else if it's the main admin
     if (editingUser && editingUser.username === 'admin' && formData.username !== 'admin') {
        setError("لا يمكن تغيير اسم المستخدم الخاص بالمدير الرئيسي 'admin'.");
        return;
    }


    if (editingUser) {
      const updatedUsers = users.map(u => 
        u.id === editingUser.id ? { ...u, username: formData.username.trim(), role: formData.role, ...(formData.password?.trim() && { password: formData.password.trim() }) } : u
      );
      saveUsers(updatedUsers);
    } else {
      if (users.find(u => u.username.toLowerCase() === formData.username.trim().toLowerCase())) {
        setError("اسم المستخدم هذا موجود بالفعل.");
        return;
      }
      const newUser: User = {
        id: `user-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        username: formData.username.trim(),
        role: formData.role,
        password: formData.password?.trim(), // In real app, hash this
      };
      saveUsers([...users, newUser]);
    }
    handleCloseModal();
  };

  const handleDeleteUser = (userId: string) => {
    const userToDelete = users.find(u => u.id === userId);
    if (!userToDelete) return;

    if (userToDelete.username === 'admin' || userToDelete.id === currentUser?.id) {
        alert("لا يمكن حذف حساب المدير الرئيسي أو حسابك الحالي.");
        return;
    }
    if (window.confirm(`هل أنت متأكد أنك تريد حذف المستخدم '${userToDelete.username}'؟ هذا الإجراء لا يمكن التراجع عنه.`)) {
      saveUsers(users.filter(u => u.id !== userId));
    }
  };
  
  const userRoleOptions = USER_ROLES.map(role => ({ value: role, label: role }));

  const filteredUsers = users.filter(user => 
    user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.role.toLowerCase().includes(searchTerm.toLowerCase())
  ).sort((a, b) => a.username.localeCompare(b.username));


  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl sm:text-4xl font-bold text-indigo-800">إدارة المستخدمين</h1>
        <Button onClick={() => handleOpenModal()} variant="primary" size="md">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 inline ml-2" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
            </svg>
            إضافة مستخدم جديد
        </Button>
      </div>

      <Input
        type="search"
        placeholder="ابحث باسم المستخدم أو الدور..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        label="بحث عن مستخدم:"
        id="user-search"
        containerClassName="mb-0"
      />
      
      <div className="bg-white shadow-xl rounded-xl overflow-hidden">
        <ul className="divide-y divide-slate-200">
          {filteredUsers.map((user) => (
            <li key={user.id} className="px-5 py-4 sm:px-7 sm:py-5 hover:bg-slate-50 transition-colors duration-150 ease-in-out">
              <div className="flex items-center justify-between gap-4">
                <div className="truncate flex-1">
                  <p className="text-lg font-semibold text-indigo-700 truncate">{user.username}</p>
                  <p className={`text-sm px-2 py-0.5 inline-block rounded-full ${user.role === UserRole.ADMIN ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-600'}`}>{user.role}</p>
                </div>
                <div className="ml-2 flex-shrink-0 flex space-x-2 space-x-reverse">
                  <Button onClick={() => handleOpenModal(user)} variant="neutral" size="sm">تعديل</Button>
                  <Button 
                    onClick={() => handleDeleteUser(user.id)} 
                    variant="danger" 
                    size="sm" 
                    disabled={user.username === 'admin' || user.id === currentUser?.id}
                    title={user.username === 'admin' || user.id === currentUser?.id ? "لا يمكن حذف هذا المستخدم" : "حذف المستخدم"}
                  >
                    حذف
                  </Button>
                </div>
              </div>
            </li>
          ))}
        </ul>
         {filteredUsers.length === 0 && (
            <div className="text-center text-slate-500 py-12">
                <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
                <p className="text-lg mt-3 font-medium">
                    {searchTerm ? "لم يتم العثور على مستخدمين يطابقون بحثك." : "لا يوجد مستخدمون لعرضهم."}
                </p>
                {!searchTerm && <p className="text-sm">قم بإضافة مستخدم جديد للبدء.</p>}
            </div>
         )}
      </div>

      <Modal isOpen={isModalOpen} onClose={handleCloseModal} title={editingUser ? 'تعديل مستخدم' : 'إضافة مستخدم جديد'}>
        <form onSubmit={handleSubmit} className="space-y-5" noValidate>
          {error && <p className="text-sm text-red-700 bg-red-100 p-3 rounded-lg font-medium">{error}</p>}
          <Input 
            label="اسم المستخدم" 
            name="username" 
            value={formData.username} 
            onChange={(e) => setFormData({...formData, username: e.target.value})} 
            required 
            aria-required="true"
            disabled={editingUser?.username === 'admin'}
            title={editingUser?.username === 'admin' ? "لا يمكن تغيير اسم المستخدم الخاص بالمدير 'admin'" : ""}
          />
          <Input 
            label="كلمة المرور" 
            name="password" 
            type="password"
            value={formData.password || ''} 
            onChange={(e) => setFormData({...formData, password: e.target.value})} 
            placeholder={editingUser ? "اتركه فارغاً لعدم التغيير" : "6 أحرف على الأقل"}
            required={!editingUser}
            aria-required={!editingUser}
            minLength={editingUser ? undefined : 6}
          />
          <Select 
            label="الدور" 
            name="role" 
            options={userRoleOptions} 
            value={formData.role} 
            onChange={(e) => setFormData({...formData, role: e.target.value as UserRole})} 
            required 
            aria-required="true"
            disabled={editingUser?.username === 'admin'}
            title={editingUser?.username === 'admin' ? "لا يمكن تغيير دور المدير 'admin'" : ""}
          />
          <div className="flex justify-end space-x-3 space-x-reverse pt-3">
            <Button type="button" variant="neutral" onClick={handleCloseModal}>إلغاء</Button>
            <Button type="submit" variant="primary">{editingUser ? 'حفظ التغييرات' : 'إضافة مستخدم'}</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default UserManagementPage;