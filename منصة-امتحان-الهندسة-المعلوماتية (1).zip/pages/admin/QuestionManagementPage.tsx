
import React, { useState, useMemo } from 'react';
import { Question, NewQuestionData, EditQuestionData, QuestionFilterCriteria } from '../../types';
import { useData } from '../../contexts/DataContext';
import QuestionList from '../../components/admin/QuestionListItem'; 
import QuestionForm from '../../components/admin/QuestionForm';
import QuestionFilter from '../../components/admin/QuestionFilter';
import Button from '../../components/shared/Button';
import Modal from '../../components/shared/Modal';
import Input from '../../components/shared/Input'; 

const QuestionManagementPage: React.FC = () => {
  const { questions, addQuestion, updateQuestion, deleteQuestion, getFilteredQuestions } = useData();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
  const [filters, setFilters] = useState<QuestionFilterCriteria>({specialization: '', source: ''});
  
  const [searchTerm, setSearchTerm] = useState(''); 

  const manualQuestionsCount = useMemo(() => questions.filter(q => !q.isAIGenerated).length, [questions]);
  const aiQuestionsCount = useMemo(() => questions.filter(q => q.isAIGenerated).length, [questions]);
  const totalQuestionsCount = questions.length;

  const handleOpenModal = (question?: Question) => {
    setEditingQuestion(question || null);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setEditingQuestion(null);
    setIsModalOpen(false);
  };

  const handleSubmitQuestion = (data: NewQuestionData | EditQuestionData) => {
    if ('id' in data && data.id) { 
      updateQuestion(data as EditQuestionData);
    } else {
      addQuestion(data as NewQuestionData);
    }
    handleCloseModal();
  };

  const handleDeleteQuestion = (id: string) => {
    if (window.confirm('هل أنت متأكد أنك تريد حذف هذا السؤال؟ هذا الإجراء لا يمكن التراجع عنه.')) {
      deleteQuestion(id);
    }
  };
  
  const handleFilterChange = (newFilters: QuestionFilterCriteria) => {
    setFilters(newFilters);
  };

  const filteredAndSearchedQuestions = useMemo(() => {
    let currentQuestions = getFilteredQuestions(filters);
    if (searchTerm.trim() !== '') {
      const lowerSearchTerm = searchTerm.toLowerCase();
      currentQuestions = currentQuestions.filter(q => 
        q.text.toLowerCase().includes(lowerSearchTerm) ||
        q.specialization.toLowerCase().includes(lowerSearchTerm) ||
        q.options.some(opt => opt.text.toLowerCase().includes(lowerSearchTerm))
      );
    }
    return currentQuestions.sort((a,b) => a.text.localeCompare(b.text)); 
  }, [filters, searchTerm, getFilteredQuestions, questions]); 


  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl sm:text-4xl font-bold text-indigo-800">إدارة الأسئلة</h1>
          <p className="text-sm text-slate-600 mt-1">
            الإجمالي: <span className="font-semibold">{totalQuestionsCount}</span> سؤال 
            ( <span className="font-medium">{manualQuestionsCount}</span> يدوي / <span className="font-medium">{aiQuestionsCount}</span> مولّد بـAI )
          </p>
        </div>
        <Button onClick={() => handleOpenModal()} variant="primary" size="md" className="flex-shrink-0">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 inline ml-2" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
            </svg>
            إضافة سؤال جديد (يدوي)
        </Button>
      </div>

      <QuestionFilter onFilterChange={handleFilterChange} initialFilters={filters} />
      
      <div className="mb-6">
          <Input 
            type="search"
            placeholder="ابحث في نص السؤال, التخصص, أو الخيارات..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            label="بحث سريع:"
            id="question-search"
            containerClassName="mb-0"
          />
      </div>

      {filteredAndSearchedQuestions.length > 0 ? (
        <div className="space-y-6"> 
          {filteredAndSearchedQuestions.map(q => (
            <QuestionList 
              key={q.id} 
              question={q} 
              onEdit={() => handleOpenModal(q)} 
              onDelete={() => handleDeleteQuestion(q.id)} 
            />
          ))}
        </div>
      ) : (
        <div className="text-center text-slate-500 py-12 bg-white rounded-xl shadow-lg">
            <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-16 w-16 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1">
              <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
            </svg>
            <p className="text-xl mt-4 font-semibold">
              {searchTerm || filters.specialization || filters.source ? "لا توجد أسئلة تطابق بحثك أو فلاترك" : "لا توجد أسئلة لعرضها"}
            </p>
            <p className="mt-2">
              {searchTerm || filters.specialization || filters.source ? "حاول تعديل الفلاتر أو مصطلح البحث." : "قم بإضافة سؤال جديد للبدء."}
            </p>
        </div>
      )}

      <Modal 
        isOpen={isModalOpen} 
        onClose={handleCloseModal} 
        title={editingQuestion ? 'تعديل السؤال' : 'إضافة سؤال جديد (يدوي)'}
        size="xl"
      >
        <QuestionForm 
          onSubmit={handleSubmitQuestion} 
          initialData={editingQuestion} 
          onCancel={handleCloseModal}
        />
      </Modal>
    </div>
  );
};

export default QuestionManagementPage;