import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useData } from '../../contexts/DataContext';
import Button from '../../components/shared/Button';
import { APP_NAME, SPECIALIZATIONS } from '../../constants';
import { Specialization, ExamAttempt, ExamType } from '../../types';

// Placeholder Icons (simple SVGs)
const CodeIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-sky-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M10 20l4-16m4 16l-4-16M4 9h16M4 15h16" /></svg>;
const NetworkIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-sky-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M9 10h.01M15 10h.01M21 12a9 9 0 00-9-9m9 9a9 9 0 01-9 9m9-9H3m9 9a9 9 0 009-9M3 12a9 9 0 019-9" /></svg>;
const AiIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-sky-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>;
const DatabaseIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-sky-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s8-1.79-8-4" /></svg>;
const ScreenIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-sky-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>;
const DocumentIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-sky-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>;
const PlayIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 inline mr-2" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>;
const HistoryIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const CheckCircleIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-500" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>;
const XCircleIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-500" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" /></svg>;
const SparklesIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 inline-block mr-1" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5 2a1 1 0 011 1v1h1a1 1 0 010 2H6v1a1 1 0 01-2 0V6H3a1 1 0 010-2h1V3a1 1 0 011-1zm0 10a1 1 0 011 1v1h1a1 1 0 110 2H6v1a1 1 0 11-2 0v-1H3a1 1 0 110-2h1v-1a1 1 0 011-1zM12 2a1 1 0 011 1v1h1a1 1 0 110 2h-1v1a1 1 0 11-2 0V6h-1a1 1 0 010-2h1V3a1 1 0 011-1zm-1 6a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 01-1 1h-2a1 1 0 01-1-1V8zM17 8a1 1 0 00-1 1v1h-1a1 1 0 100 2h1v1a1 1 0 102 0v-1h1a1 1 0 100-2h-1V9a1 1 0 00-1-1z" clipRule="evenodd" /></svg>;
const BookOpenIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 inline-block mr-1" viewBox="0 0 20 20" fill="currentColor"><path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" /><path fillRule="evenodd" d="M5 4a3 3 0 016 0v1.586l-2.293-2.293a1 1 0 00-1.414 0L5 5.586V4z" clipRule="evenodd" /></svg>;

const specializationsData = [
  { id: Specialization.SOFTWARE_ENGINEERING, name: Specialization.SOFTWARE_ENGINEERING, Icon: CodeIcon, description: "تصميم وتطوير تطبيقات وأنظمة برمجية قوية وقابلة للتطوير لتلبية احتياجات المستخدمين المتنوعة." },
  { id: Specialization.NETWORK_ENGINEERING, name: Specialization.NETWORK_ENGINEERING, Icon: NetworkIcon, description: "بناء وإدارة شبكات الحاسوب الآمنة والفعالة، وضمان تدفق البيانات بسلاسة وكفاءة عالية." },
  { id: Specialization.ARTIFICIAL_INTELLIGENCE, name: "الذكاء الاصطناعي", Icon: AiIcon, description: "تطوير أنظمة ذكية قادرة على التعلم، تحليل البيانات، اتخاذ القرارات، ومحاكاة القدرات البشرية." },
  { id: Specialization.GENERAL, name: "التخصص العام", Icon: DatabaseIcon, description: "فهم المبادئ الأساسية لعلوم الحاسوب، الخوارزميات، وهياكل البيانات التي تدعم جميع التخصصات." },
];

const featuresData = [
  {
    title: "بنك أسئلة متكامل",
    description: "يضم آلاف الأسئلة المصنفة حسب التخصص والموضوع، مع شروحات مفصلة تساعدك على فهم المفاهيم بشكل أفضل.",
    image: "https://images.unsplash.com/photo-1544716278-e513176f20b5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=60",
    type: "imageTop"
  },
  {
    title: "تتبع تقدمك",
    description: "لوحة تحكم شخصية تمكنك من متابعة أدائك في كل تخصص، مع إحصائيات وتحليلات تساعدك على معرفة نقاط القوة والضعف.",
    image: "https://images.unsplash.com/photo-1503428593586-e225b39bddfe?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=60",
    type: "imageTop"
  },
  {
    title: "امتحانات تجريبية",
    description: "اختبارات محاكاة للامتحان الحقيقي، مع تصحيح فوري وتحليل للأداء بعد كل اختبار، مما يساعدك على الاستعداد الأمثل.",
    Icon: ScreenIcon,
    type: "iconSide"
  },
  {
    title: "مصادر تعليمية",
    description: "مجموعة متنوعة من الملفات التعليمية والمراجع في مختلف التخصصات، لتوسيع معرفتك وتعزيز فهمك للمواد الدراسية.",
    Icon: DocumentIcon,
    type: "iconSide"
  }
];


const StudentDashboardPage: React.FC = () => {
  const { user } = useAuth();
  const { getExamAttemptsByUserId } = useData();

  if (!user) return null;

  const userAttempts = getExamAttemptsByUserId(user.id).slice(0, 3); // Get last 3 attempts

  const getMotivationalQuote = () => {
    const quotes = [
      "النجاح ليس نهاية، والفشل ليس قاتلاً: إنما الشجاعة لمواصلة هذا ما يهم. - ونستون تشرشل",
      "لا تنتظر الفرصة، اصنعها بنفسك.",
      "كل يوم هو فرصة جديدة لتصبح أفضل.",
      "الاستثمار في المعرفة يدفع أفضل الفوائد. - بنجامين فرانكلين",
      "الطريق إلى النجاح ممهد دائماً بالعمل الجاد."
    ];
    return quotes[Math.floor(Math.random() * quotes.length)];
  };

  return (
    <div className="bg-slate-100 text-slate-800">
      {/* Hero Section */}
      <section 
        className="bg-slate-800 text-white py-20 md:py-28 px-4 text-center relative overflow-hidden"
      >
        <div className="relative z-10">
           <h1 className="text-3xl md:text-4xl font-semibold mb-3 animate-fade-in-down" style={{ animationDelay: '0.1s' }}>
            أهلاً بك مجدداً، <span className="text-sky-300 font-bold">{user.username}!</span>
          </h1>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 drop-shadow-md animate-fade-in-down" style={{ animationDelay: '0.3s' }}>
            {APP_NAME}
          </h2>
          <p className="text-lg md:text-xl text-slate-300 mb-10 max-w-2xl mx-auto drop-shadow-sm animate-fade-in-up" style={{ animationDelay: '0.5s' }}>
             {getMotivationalQuote()}
          </p>
          <Link to="/student/exam/take">
            <Button variant="primary" size="lg" className="bg-sky-500 hover:bg-sky-600 text-white !px-8 !py-3.5 text-lg animate-fade-in-up" style={{ animationDelay: '0.7s' }}>
              بدء امتحان الآن
            </Button>
          </Link>
        </div>
      </section>

      {/* Recent Exam Attempts Section */}
      <section className="py-16 md:py-20 bg-white px-4">
        <div className="container mx-auto">
          <div className="flex items-center justify-between mb-10">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-700">آخر محاولاتك الامتحانية</h2>
            <HistoryIcon />
          </div>
          {userAttempts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-10">
              {userAttempts.map((attempt, index) => {
                const percentage = attempt.totalMarks > 0 ? Math.round((attempt.score / attempt.totalMarks) * 100) : 0;
                const passed = percentage >= 50;
                return (
                  <div 
                    key={attempt.id} 
                    className="bg-slate-50 p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col animate-fade-in-up" 
                    style={{ animationDelay: `${0.1 * (index + 1)}s` }}
                  >
                    <div className="flex items-center mb-3">
                      {passed ? <CheckCircleIcon /> : <XCircleIcon />}
                      <h3 className="text-lg font-semibold text-slate-700 mr-2">{attempt.specialization}</h3>
                    </div>
                    <p className="text-sm text-slate-500 mb-1">
                      {attempt.examType === ExamType.SMART ? <SparklesIcon /> : <BookOpenIcon /> }
                      نوع الامتحان: {attempt.examType === ExamType.SMART ? 'ذكي' : 'اعتيادي'}
                    </p>
                    <p className="text-sm text-slate-500 mb-3">
                      تاريخ التقديم: {new Date(attempt.submittedAt).toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' })}
                    </p>
                    <div className="my-3 p-3 bg-white rounded-lg border border-slate-200 text-center">
                      <p className="text-sm text-slate-600">النتيجة:</p>
                      <p className={`text-2xl font-bold ${passed ? 'text-green-600' : 'text-red-600'}`}>
                        {attempt.score} / {attempt.totalMarks} ({percentage}%)
                      </p>
                    </div>
                    <div className="mt-auto pt-3">
                      <Link to={`/student/exam/results/${attempt.id}`}>
                        <Button variant="neutral" size="sm" className="w-full">
                          مراجعة الامتحان &larr;
                        </Button>
                      </Link>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12 bg-slate-50 rounded-xl shadow-md animate-fade-in-up">
              <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-16 w-16 text-slate-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1"><path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>
              <p className="text-xl text-slate-600 font-semibold mb-2">لم تقم بأي امتحانات بعد.</p>
              <p className="text-slate-500 mb-6">ابدأ رحلتك التعليمية واختبر معلوماتك الآن!</p>
              <Link to="/student/exam/take">
                <Button variant="primary" size="md">
                  ابدأ أول امتحان لك
                </Button>
              </Link>
            </div>
          )}
        </div>
      </section>


      {/* Main Specializations Section */}
      <section className="py-16 md:py-20 bg-slate-100 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-700 text-center mb-16">اختبر معلوماتك في التخصصات الرئيسية</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {specializationsData.map((spec, index) => (
              <div key={spec.id} className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col items-center text-center animate-fade-in-up" style={{ animationDelay: `${0.2 * (index + 1)}s` }}>
                <div className="p-4 bg-sky-100 rounded-full mb-6">
                  <spec.Icon />
                </div>
                <h3 className="text-xl font-semibold text-slate-700 mb-3">{spec.name}</h3>
                <p className="text-slate-500 text-sm mb-6 flex-grow">{spec.description}</p>
                <Link to="/student/exam/take" state={{ specialization: spec.id }} className="w-full">
                    <Button variant='secondary' size='sm' className='w-full text-sm'>
                        ابدأ امتحان في {spec.name}
                    </Button>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Platform Features Section */}
      <section className="py-16 md:py-20 bg-white px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-700 text-center mb-16">مميزات المنصة</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {featuresData.map((feature, index) => (
              <div 
                key={feature.title} 
                className={`bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 overflow-hidden flex ${feature.type === 'imageTop' ? 'flex-col' : 'flex-col sm:flex-row items-start'} animate-fade-in-up`}
                style={{ animationDelay: `${0.2 * (index + 1)}s` }}
              >
                {feature.type === 'imageTop' && feature.image && (
                  <img src={feature.image} alt={feature.title} className="w-full h-56 object-cover" />
                )}
                <div className={`p-6 ${feature.type === 'iconSide' ? 'flex-grow' : ''}`}>
                  <div className={`flex items-center ${feature.type === 'iconSide' ? 'mb-3' : 'mb-4'}`}>
                    {feature.type === 'iconSide' && feature.Icon && (
                      <div className="p-3 bg-sky-100 rounded-lg mr-4 rtl:ml-4 rtl:mr-0">
                        <feature.Icon />
                      </div>
                    )}
                    <h3 className="text-xl font-semibold text-slate-700">{feature.title}</h3>
                  </div>
                  <p className="text-slate-500 text-sm leading-relaxed">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Call to Action Section */}
      <section className="py-16 md:py-24 bg-sky-500 text-white px-4">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-in-down">مستعد للتحدي؟</h2>
          <p className="text-lg text-sky-100 mb-10 max-w-xl mx-auto animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
            انضم إلى آلاف الطلاب الذين يستعدون لامتحان الهندسة المعلوماتية الموحد واختبر معلوماتك اليوم.
          </p>
          <Link to="/student/exam/take">
            <Button variant="neutral" size="lg" className="bg-white hover:bg-slate-100 text-sky-600 !px-8 !py-3.5 text-lg animate-fade-in-up" style={{ animationDelay: '0.6s' }}>
              <PlayIcon />
              بدء امتحان تجريبي
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default StudentDashboardPage;
