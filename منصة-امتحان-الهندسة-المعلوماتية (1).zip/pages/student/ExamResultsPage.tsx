
import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ExamAttempt, ExamType } from '../../types';
import { useData } from '../../contexts/DataContext';
import { useAuth } from '../../contexts/AuthContext';
import ExamReviewItem from '../../components/student/ExamReviewItem';
import Button from '../../components/shared/Button';

const ExamResultsPage: React.FC = () => {
  const { attemptId } = useParams<{ attemptId: string }>();
  const { user } = useAuth();
  const { getExamAttemptById } = useData();
  const navigate = useNavigate();
  const [attempt, setAttempt] = useState<ExamAttempt | null | undefined>(undefined); // undefined for loading, null for not found

  useEffect(() => {
    if (attemptId) {
      const foundAttempt = getExamAttemptById(attemptId);
      if (foundAttempt && user && foundAttempt.userId === user.id) {
        setAttempt(foundAttempt);
      } else if (foundAttempt) { 
        console.warn("Access denied for exam attempt:", attemptId);
        setAttempt(null); 
        navigate("/student", {replace: true}); 
      } else {
        setAttempt(null); 
      }
    } else {
        setAttempt(null); // No attemptId provided
    }
  }, [attemptId, getExamAttemptById, user, navigate]);

  if (attempt === undefined) {
    return (
        <div className="flex flex-col items-center justify-center min-h-[70vh] text-center p-5">
            <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mb-5"></div>
            <p className="text-slate-600 text-lg">جارٍ تحميل النتائج...</p>
        </div>
    );
  }

  if (attempt === null) {
    return (
      <div className="text-center py-12 bg-white rounded-xl shadow-xl p-8 max-w-lg mx-auto">
        <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-20 w-20 text-red-500 mb-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1">
            <path strokeLinecap="round" strokeLinejoin="round" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
        </svg>
        <h1 className="text-3xl font-bold text-red-700 mb-4">لم يتم العثور على محاولة الامتحان</h1>
        <p className="text-slate-600 mb-8">قد يكون الرابط غير صحيح أو أنك لا تملك صلاحية عرض هذه النتائج.</p>
        <Link to="/student">
          <Button variant="primary" size="md">العودة إلى لوحة التحكم</Button>
        </Link>
      </div>
    );
  }

  // totalMarks is now the number of questions in the attempt. Score is number of correct answers.
  const percentage = attempt.totalMarks > 0 ? Math.round((attempt.score / attempt.totalMarks) * 100) : 0;
  const passed = attempt.score >= attempt.totalMarks / 2; // Assuming passing is 50%
  const examTypeDisplay = attempt.examType === ExamType.SMART ? "الذكي" : "الاعتيادي";

  return (
    <div className="space-y-10">
      <div className={`p-8 rounded-xl shadow-2xl text-center border-t-8 ${passed ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50'}`}>
        <div className={`mx-auto mb-5 w-20 h-20 rounded-full flex items-center justify-center ${passed ? 'bg-green-500' : 'bg-red-500'}`}>
            {passed ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            ) : (
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            )}
        </div>
        <h1 className={`text-3xl sm:text-4xl font-bold mb-3 ${passed ? 'text-green-700' : 'text-red-700'}`}>
          {passed ? 'تهانينا! لقد نجحت في الامتحان.' : 'للأسف، لم تنجح هذه المرة.'}
        </h1>
        <p className="text-2xl font-semibold text-slate-800 mb-2">
          نتيجتك: <span className={`font-extrabold ${passed? 'text-green-600' : 'text-red-600'}`}>{attempt.score}</span> إجابات صحيحة من أصل {attempt.totalMarks} سؤال <span className="text-slate-600">({percentage}%)</span>
        </p>
        <p className="text-md text-slate-500">
          التخصص: <span className="font-medium text-indigo-600">{attempt.specialization}</span> | نوع الامتحان: <span className="font-medium text-indigo-600">{examTypeDisplay}</span>
        </p>
        <p className="text-md text-slate-500 mt-1">
          تاريخ التقديم: {new Date(attempt.submittedAt).toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' })}
        </p>
      </div>

      <div className="bg-white p-6 sm:p-8 rounded-xl shadow-xl">
        <h2 className="text-2xl font-semibold text-indigo-800 mb-8 text-center">مراجعة تفصيلية للأسئلة</h2>
        {attempt.questions.map((q, index) => (
          <ExamReviewItem
            key={q.id}
            question={q}
            studentAnswer={attempt.answers.find(ans => ans.questionId === q.id)}
            questionIndex={index}
          />
        ))}
      </div>

      <div className="text-center mt-12 pb-5 space-y-4 sm:space-y-0 sm:space-x-4 sm:space-x-reverse">
        <Link to="/student/exam/take">
          <Button variant="primary" size="lg" className="w-full sm:w-auto">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 inline ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
            </svg>
            إجراء امتحان جديد
          </Button>
        </Link>
        <Link to="/student">
          <Button variant="neutral" size="lg" className="w-full sm:w-auto">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 inline ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
            </svg>
            العودة إلى لوحة التحكم
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default ExamResultsPage;
