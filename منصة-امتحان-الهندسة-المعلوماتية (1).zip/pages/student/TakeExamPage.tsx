import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Question, Specialization, ExamAnswer, ExamAttempt, ExamType, NewQuestionData } from '../../types';
import { useData } from '../../contexts/DataContext';
import { useAuth } from '../../contexts/AuthContext';
import ExamSetupForm from '../../components/student/ExamSetupForm';
import ExamQuestionView from '../../components/student/ExamQuestionView';
import Button from '../../components/shared/Button';
import Modal from '../../components/shared/Modal'; 
import { generateSmartQuestions } from '../../services/aiQuestionService';
import { MIN_SAMPLE_QUESTIONS_FOR_SMART_EXAM, SPECIALIZATIONS } from '../../constants';


// Shuffle array utility
function shuffleArray<T,>(array: T[]): T[] {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}

const TakeExamPage: React.FC = () => {
  const { user } = useAuth();
  const { addExamAttempt, getFilteredQuestions, addQuestion } = useData(); 
  const navigate = useNavigate();
  const location = useLocation(); // Get location to access state

  // Set initial specialization from location state if available
  const initialSpecializationFromState = (location.state as { specialization?: Specialization })?.specialization;
  const validInitialSpecialization = initialSpecializationFromState && SPECIALIZATIONS.includes(initialSpecializationFromState)
    ? initialSpecializationFromState
    : SPECIALIZATIONS[0];


  const [examStage, setExamStage] = useState<'setup' | 'generating' | 'taking' | 'submitting'>('setup');
  const [examQuestions, setExamQuestions] = useState<Question[]>([]);
  const [currentAnswers, setCurrentAnswers] = useState<ExamAnswer[]>([]);
  const [examSpecialization, setExamSpecialization] = useState<Specialization | null>(initialSpecializationFromState || null);
  const [currentExamType, setCurrentExamType] = useState<ExamType>(ExamType.REGULAR);
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [generationError, setGenerationError] = useState<string | null>(null);
  
  const availableQuestionsCount = useCallback((spec: Specialization): number => {
    return getFilteredQuestions({ specialization: spec, source: 'manual' }).length; // Consider only manual for regular exam source
  }, [getFilteredQuestions]);

  const handleSetupSubmit = async (specialization: Specialization, numQuestions: number, examType: ExamType) => {
    setExamSpecialization(specialization);
    setCurrentExamType(examType);
    setGenerationError(null);

    if (examType === ExamType.REGULAR) {
      // For regular exams, use any available questions (manual or previously saved AI)
      const filtered = getFilteredQuestions({ specialization });
      const shuffled = shuffleArray(filtered);
      const actualNumQuestions = Math.min(numQuestions, shuffled.length);
      const selectedQuestions = shuffled.slice(0, actualNumQuestions);
      
      setExamQuestions(selectedQuestions);
      setCurrentAnswers(selectedQuestions.map(q => ({ questionId: q.id, selectedOptionId: undefined })));
      setExamStage('taking');
    } else if (examType === ExamType.SMART) {
      setExamStage('generating');
      try {
        // Sample questions for AI can be any type, including existing AI ones.
        const sampleQuestions = getFilteredQuestions({ specialization }); 
        if (sampleQuestions.length < MIN_SAMPLE_QUESTIONS_FOR_SMART_EXAM) {
          setGenerationError(`لا يمكن إنشاء امتحان ذكي لـ ${specialization} بسبب عدم وجود أسئلة كافية كمرجع (${sampleQuestions.length} متوفر, ${MIN_SAMPLE_QUESTIONS_FOR_SMART_EXAM} مطلوب).`);
          setExamStage('setup'); 
          return;
        }
        const aiGeneratedRawQuestions = await generateSmartQuestions(specialization, numQuestions, sampleQuestions);
        
        if (aiGeneratedRawQuestions.length === 0) {
            setGenerationError("فشل الذكاء الاصطناعي في توليد أي أسئلة. يرجى المحاولة مرة أخرى أو اختيار امتحان اعتيادي.");
            setExamStage('setup');
            return;
        }

        const savedAiQuestions: Question[] = [];
        // Save AI generated questions to the main question bank
        aiGeneratedRawQuestions.forEach(aiQuestion => {
          // The AI service now returns full Question objects with isAIGenerated: true
          // We need to prepare it as NewQuestionData for the addQuestion function
          const { id, attachments, ...restOfAiQuestion } = aiQuestion; 
          
          const newQuestionDataForSave: NewQuestionData = {
            ...restOfAiQuestion, // This already includes specialization, text, options, correctOptionId
            isAIGenerated: true, // Explicitly ensure this is set for saving
            attachments: attachments.map(({ id: attId, ...restAtt }) => restAtt), // Map attachments to NewAttachment format
          };
          try {
            const savedQ = addQuestion(newQuestionDataForSave);
            savedAiQuestions.push(savedQ); // Use the question object returned by addQuestion, which has a new ID
          } catch (saveError) {
            console.error("Failed to save AI generated question to bank:", saveError, newQuestionDataForSave);
            // If saving fails, we can still use the raw AI question for the current exam, but it won't be in the bank.
            // For simplicity, we'll use the raw ones if saving fails. Better UX for student.
            // However, aiQuestion doesn't have an ID yet in the way DataContext structures it.
            // The generateSmartQuestions *does* assign a temporary ID.
            // For the exam, use the questions as returned by generateSmartQuestions if saving fails.
            // The current implementation of generateSmartQuestions returns Question[] objects with IDs.
            savedAiQuestions.push(aiQuestion); 
          }
        });
        
        setExamQuestions(savedAiQuestions.length > 0 ? savedAiQuestions : aiGeneratedRawQuestions);
        setCurrentAnswers( (savedAiQuestions.length > 0 ? savedAiQuestions : aiGeneratedRawQuestions).map(q => ({ questionId: q.id, selectedOptionId: undefined })));
        setExamStage('taking');
      } catch (error: any) {
        console.error("Error during smart exam setup (generation or saving):", error);
        setGenerationError(error.message || "حدث خطأ غير متوقع أثناء إعداد الامتحان الذكي.");
        setExamStage('setup'); 
      }
    }
  };

  const handleOptionSelect = (questionId: string, optionId: string) => {
    setCurrentAnswers(prevAnswers =>
      prevAnswers.map(ans =>
        ans.questionId === questionId ? { ...ans, selectedOptionId: optionId } : ans
      )
    );
  };

  const handleSubmitExam = () => {
    setIsConfirmModalOpen(true);
  };

  const confirmSubmitExam = () => {
    setIsConfirmModalOpen(false);
    setExamStage('submitting');

    if (!user || !examSpecialization) {
        console.error("User or specialization missing during submission");
        navigate("/student"); 
        return;
    }

    let score = 0;
    const totalMarks = examQuestions.length; 

    examQuestions.forEach(q => {
      const studentAnswer = currentAnswers.find(ans => ans.questionId === q.id);
      if (studentAnswer?.selectedOptionId === q.correctOptionId) {
        score += 1; 
      }
    });

    const attempt: ExamAttempt = {
      id: `attempt-${Date.now()}-${Math.random().toString(36).substr(2,5)}`,
      userId: user.id,
      specialization: examSpecialization,
      examType: currentExamType, 
      questions: examQuestions,
      answers: currentAnswers,
      score,
      totalMarks,
      submittedAt: new Date().toISOString(),
    };

    addExamAttempt(attempt);
    setTimeout(() => {
        navigate(`/student/exam/results/${attempt.id}`);
    }, 1200);
  };
  
  const answeredQuestionsCount = currentAnswers.filter(ans => ans.selectedOptionId !== undefined).length;
  const progressPercentage = examQuestions.length > 0 ? Math.round((answeredQuestionsCount / examQuestions.length) * 100) : 0;


  if (examStage === 'setup') {
    return (
        <>
            {generationError && (
                 <div className="max-w-lg mx-auto mb-6 p-4 bg-red-100 text-red-700 rounded-lg shadow text-sm">
                    <p className="font-semibold">خطأ في إعداد الامتحان الذكي:</p>
                    <p>{generationError}</p>
                 </div>
            )}
            <ExamSetupForm 
              onSubmit={handleSetupSubmit} 
              availableQuestionsCount={availableQuestionsCount}
              // Pass initialSpecialization to ExamSetupForm
              key={validInitialSpecialization} // Re-mount form if initial spec changes via navigation
              initialSpecialization={validInitialSpecialization}
            />
        </>
    );
  }
  
  if (examStage === 'generating') {
    return (
        <div className="flex flex-col items-center justify-center min-h-[70vh] text-center p-5">
            <div className="w-16 h-16 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mb-6"></div>
            <h2 className="text-3xl font-semibold text-indigo-700">جاري توليد أسئلة الامتحان الذكي وحفظها...</h2>
            <p className="text-slate-600 mt-3 text-lg">قد يستغرق هذا بضع لحظات. شكراً لصبرك.</p>
        </div>
    );
  }


  if (examStage === 'submitting') {
    return (
        <div className="flex flex-col items-center justify-center min-h-[70vh] text-center p-5">
            <div className="w-16 h-16 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mb-6"></div>
            <h2 className="text-3xl font-semibold text-indigo-700">جاري تصحيح الامتحان...</h2>
            <p className="text-slate-600 mt-3 text-lg">لحظات قليلة وسيتم توجيهك لصفحة النتائج.</p>
        </div>
    );
  }

  return (
    <div className="space-y-10">
      <div className="text-center">
        <h1 className="text-3xl sm:text-4xl font-bold text-indigo-800">
            امتحان {currentExamType === ExamType.SMART ? "ذكي" : "اعتيادي"} في {examSpecialization}
        </h1>
        <p className="text-lg text-slate-600 mt-2">أجب على الأسئلة التالية بعناية.</p>
      </div>
      
      <div className="sticky top-[calc(theme(spacing.16)+1rem)] sm:top-[calc(theme(spacing.20)+1rem)] z-40 bg-white/80 backdrop-blur-md p-4 rounded-xl shadow-lg border border-slate-200">
          <div className="flex justify-between items-center mb-2">
              <p className="text-sm font-medium text-indigo-700">التقدم: {answeredQuestionsCount} / {examQuestions.length}</p>
              <p className="text-sm font-bold text-indigo-700">{progressPercentage}%</p>
          </div>
          <div className="w-full bg-slate-200 rounded-full h-2.5">
              <div 
                className="bg-indigo-600 h-2.5 rounded-full transition-all duration-300 ease-out" 
                style={{ width: `${progressPercentage}%` }}
                aria-valuenow={progressPercentage}
                aria-valuemin={0}
                aria-valuemax={100}
                role="progressbar"
                aria-label={`Progress: ${progressPercentage} percent`}
              ></div>
          </div>
      </div>


      {examQuestions.map((q, index) => (
        <ExamQuestionView
          key={q.id}
          question={q}
          questionIndex={index}
          totalQuestions={examQuestions.length}
          selectedOptionId={currentAnswers.find(ans => ans.questionId === q.id)?.selectedOptionId}
          onOptionSelect={handleOptionSelect}
        />
      ))}

      <div className="mt-10 flex justify-center pb-5">
        <Button 
            onClick={handleSubmitExam} 
            variant="success" 
            size="lg" 
            disabled={examStage !== 'taking'}
            className="shadow-xl hover:shadow-2xl transform hover:scale-105"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 inline ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          تسليم الامتحان النهائي
        </Button>
      </div>

      <Modal
        isOpen={isConfirmModalOpen}
        onClose={() => setIsConfirmModalOpen(false)}
        title="تأكيد تسليم الامتحان"
      >
        <div className="text-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-16 w-16 text-amber-500 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                 <path strokeLinecap="round" strokeLinejoin="round" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.79 4 4s-1.79 4-4 4c-1.742 0-3.223-.835-3.772-2M12 12H4m4 4H4m4-8H4m12 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p className="text-slate-700 mb-3 text-lg">
                هل أنت متأكد أنك تريد تسليم الامتحان؟
            </p>
            <p className="text-sm text-slate-500 mb-6">
                لقد أجبت على <span className="font-bold text-indigo-600">{answeredQuestionsCount}</span> من <span className="font-bold text-indigo-600">{examQuestions.length}</span> أسئلة. <br/>
                لا يمكنك تغيير إجاباتك بعد التسليم.
            </p>
        </div>
        <div className="flex justify-center space-x-4 space-x-reverse">
          <Button variant="neutral" onClick={() => setIsConfirmModalOpen(false)} size="md">إلغاء</Button>
          <Button variant="success" onClick={confirmSubmitExam} size="md">نعم، قم بالتسليم</Button>
        </div>
      </Modal>
    </div>
  );
};

export default TakeExamPage;
